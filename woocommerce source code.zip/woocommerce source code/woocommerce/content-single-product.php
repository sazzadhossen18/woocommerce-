<?php

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>
 
 
<!--body content start-->

<div class="page-content">

<!--product details start-->

<section>
  <div class="container">
    <div class="row">

      <div class="col-lg-6 col-12">
         

        <ul id="imageGallery">

        <?php echo woocommerce_show_product_images();?>

        </ul>
      </div>
      <div class="col-lg-6 col-12 mt-5 mt-lg-0">
        <div class="product-details">











   <div class="summary entry-summary">
		<?php
		/**
		 * Hook: woocommerce_single_product_summary.
		 *
		 * @hooked woocommerce_template_single_title - 5
		 * @hooked woocommerce_template_single_rating - 10
		 * @hooked woocommerce_template_single_price - 10
		 * @hooked woocommerce_template_single_excerpt - 20
		 * @hooked woocommerce_template_single_add_to_cart - 30
		 * @hooked woocommerce_template_single_meta - 40
		 * @hooked woocommerce_template_single_sharing - 50
		 * @hooked WC_Structured_Data::generate_product_data() - 60
		 */
		do_action( 'woocommerce_single_product_summary' );
		?>
	</div>
          <h1 class="h4 mb-0 font-w-6">Unpaired Running Shoes</h1>
          <div class="star-rating mb-4"><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>
          </div> 

          <span class="product-price h5 text-pink">$25.00 
          	<del class="text-muted h6">$35.00</del>
          </span>

          <ul class="list-unstyled my-3">
            <li><small>Availibility: <span class="text-green"> In Stock</span> </small>
            </li>
            <li class="font-w-4"><small>Categories :<span class="text-muted"> womens, clothing, dresses, footwear</span></small>
            </li>
          </ul>
          <p class="mb-4 desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. vulputate adipiscing cursus eu, suscipit id nulla.</p>













          <div class="d-sm-flex align-items-center mb-5">
            <div class="d-flex align-items-center mr-sm-4">

  


 <form class="cart" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data'>

 

    <?php
   
    woocommerce_quantity_input(
      array(
        'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
        'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
        'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
      )
    );

    
 ?>
  
 
              
            </div>
            <select class="custom-select mt-3 mt-sm-0" id="inputGroupSelect02">
              <option selected>Size</option>
              <option value="1">XS</option>
              <option value="2">S</option>
              <option value="3">M</option>
              <option value="3">L</option>
              <option value="3">XL</option>
              <option value="3">XXL</option>
            </select>
            <div class="d-flex text-center ml-sm-4 mt-3 mt-sm-0">
              <div class="form-check pl-0 mr-2">
                <input type="radio" class="form-check-input" id="color-filter1" name="Radios">
                <label class="form-check-label" for="color-filter1" data-bg-color="#ffc107"></label>
              </div>
              <div class="form-check pl-0 mr-2">
                <input type="radio" class="form-check-input" id="color-filter2" name="Radios" checked>
                <label class="form-check-label" for="color-filter2" data-bg-color="#6d5b97"></label>
              </div>
              <div class="form-check pl-0 mr-2">
                <input type="radio" class="form-check-input" id="color-filter3" name="Radios">
                <label class="form-check-label" for="color-filter3" data-bg-color="#88b04b"></label>
              </div>
              <div class="form-check pl-0">
                <input type="radio" class="form-check-input" id="color-filter4" name="Radios">
                <label class="form-check-label" for="color-filter4" data-bg-color="#23a5a8"></label>
              </div>
            </div>
          </div>
          <div class="d-sm-flex align-items-center mt-5">
          	 <button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="btn-cart btn btn-pink mx-3"><i class="las la-shopping-cart mr-1"></i> <?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
          
             </form>

              <?php echo do_shortcode('[ti_wishlists_addtowishlist]')?>
            
          </div>
          
        </div>
      </div>
    </div>
  </div>
</section>

<!--product details end-->


<!--tab start-->

<section class="pt-0 pb-8">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="tab product-tab">
          <!-- Nav tabs -->

          <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist"> <a class="nav-item nav-link active ml-0" id="nav-tab1" data-toggle="tab" href="#tab3-1" role="tab" aria-selected="true">Description</a>
              <a class="nav-item nav-link" id="nav-tab2" data-toggle="tab" href="#tab3-2" role="tab" aria-selected="false">Specification</a>
              <a class="nav-item nav-link" id="nav-tab3" data-toggle="tab" href="#tab3-3" role="tab" aria-selected="false">Ratings and Reviews</a>
            </div>
          </nav>
          <!-- Tab panes -->
          <div class="tab-content pt-5 p-0">
            <div role="tabpanel" class="tab-pane fade show active" id="tab3-1">
              <div class="row align-items-center">
                
                <div class="col-md-12">


                 <?php the_content();?>
                </div>
              </div>
            </div>
            <div role="tabpanel" class="tab-pane fade" id="tab3-2">
<?php do_action( 'woocommerce_product_additional_information', $product ); ?>
            	
            
            </div>
            <div role="tabpanel" class="tab-pane fade" id="tab3-3">


            	 
             
              
              <div class="comment-area mt-5">
      <?php echo woocommerce_output_product_data_tabs();?>
                  


          <div class="mt-8 bg-light-4 rounded p-5">
                <div class="section-title mb-3">
                  <h4>Add a review</h4>
                </div>
                <form id="contact-form" class="row" method="post" action="http://themesground.com/flipmarto/demo/html/contact.php">
                  <div class="messages"></div>
                  
                  <div class="form-group col-sm-6">
                    <input id="form_name" type="text" name="name" class="form-control" placeholder="Your Name" required data-error="Name is required.">
                    <div class="help-block with-errors"></div>
                  </div>

                  <div class="form-group col-sm-6">
                    <input id="form_email" type="email" name="email" class="form-control" placeholder="Your Email Address" required data-error="Valid email is required.">
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group clearfix col-12">
                    <select class="custom-select form-control">
                      <option value="">Rating -- Select</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                    </select>
                  </div>
                  <div class="form-group col-12">
                    <textarea id="form_message" name="message" class="form-control" placeholder="Write Your Review" rows="4" required data-error="Please,leave us a review."></textarea>
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="col-12">
                    <button class="btn btn-primary btn-animated mt-1">Post Review</button>
                  </div>
                </form>
              </div>

          <div>
            
          </div>
        </div>
              
              
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--tab end-->


<!--recent product start-->

<section class="pb-6 border-top pt-7">
  <div class="container">
    <div class="row justify-content-center text-center">
      <div class="col-lg-8 col-md-10">
        <div class="mb-5">
          <h2 class="mb-0 font-w-6">Related Products</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col">
      	 <?php echo woocommerce_output_related_products();?>
       
      </div>
    </div>
  </div>
</section>

<!--recent product end-->

<!--multi sec start-->
    
    <section class="bg-pink py-9 position-relative overflow-hidden">
      <div class="container">
        <div class="row justify-content-center text-center mb-1">
          <div class="col-lg-6 col-md-10">
            <div class="mb-4">
              <h2 class="mb-0">Be the first and get weekly updates</h2>
            </div>
            <div class="subscribe-form">
              <form id="mc-form" class="row align-items-center no-gutters mb-3">
                <div class="col">
                  <input value="" name="EMAIL" class="email form-control input-2 bg-white" id="mc-email" placeholder="Email Address" required type="email">
                </div>
                <div class="col-auto">
                  <input class="btn dark-btn overflow-auto" name="subscribe" value="Subscribe" type="submit">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--multi sec end--> 

</div>

<!--body content end--> 










<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>
















	<?php
	/**
	 * Hook: woocommerce_before_single_product_summary.
	 *
	 * @hooked woocommerce_show_product_sale_flash - 10
	 * @hooked woocommerce_show_product_images - 20
	 */
	//do_action( 'woocommerce_before_single_product_summary' );
	?>

	<div class="summary entry-summary">
		<?php
		/**
		 * Hook: woocommerce_single_product_summary.
		 *
		 * @hooked woocommerce_template_single_title - 5
		 * @hooked woocommerce_template_single_rating - 10
		 * @hooked woocommerce_template_single_price - 10
		 * @hooked woocommerce_template_single_excerpt - 20
		 * @hooked woocommerce_template_single_add_to_cart - 30
		 * @hooked woocommerce_template_single_meta - 40
		 * @hooked woocommerce_template_single_sharing - 50
		 * @hooked WC_Structured_Data::generate_product_data() - 60
		 */
		//do_action( 'woocommerce_single_product_summary' );
		?>
	</div>

	<?php
	/**
	 * Hook: woocommerce_after_single_product_summary.
	 *
	 * @hooked woocommerce_output_product_data_tabs - 10
	 * @hooked woocommerce_upsell_display - 15
	 * @hooked woocommerce_output_related_products - 20
	 */
	//do_action( 'woocommerce_after_single_product_summary' );
	?>
</div>

<?php //do_action( 'woocommerce_after_single_product' ); ?>
