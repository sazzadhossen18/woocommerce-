<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-login.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

do_action( 'woocommerce_before_customer_login_form' ); ?>



  <div class="page-content">

<!--login start-->

<section class="bg-light">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-6 col-md-8 col-sm-11">
      	<div class="shadow p-6 login bg-white">
         <div class="store-name">flipmarto</div>



<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

<div class="" id="">
	

	<?php endif; ?>

	<h4 class="text-left mb-3 font-w-5">Customer Login</h4>


		<form class="" method="post">

			<?php do_action( 'woocommerce_login_form_start' ); ?>



			 
              

		 	<div class="form-group">
				<input type="text" class="form-control" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" />
				<div class="help-block with-errors"></div>
		  </div>




			<div class="form-group">
				<input class="form-control" type="password" name="password" id="password" autocomplete="current-password" />
			</div>




			<?php do_action( 'woocommerce_login_form' ); ?>









			 <div class="form-group mt-4 mb-5">
              <div class="remember-checkbox d-flex align-items-center justify-content-between">
                <div class="checkbox">
                  <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                  <label for="check2">Remember me</label>
                </div>
                 <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Forgot Password?</a>
              </div>
            </div> 
              <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
				<button type="submit" class="btn btn-primary btn-block" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce' ); ?></button>


			

			<?php do_action( 'woocommerce_login_form_end' ); ?>

		</form>

<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

	

















	

</div>
<?php endif; ?>




		</div>
		</div>
 		</div>
    </div>
  </div>
</section>

<!--login end-->

</div>      


<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
