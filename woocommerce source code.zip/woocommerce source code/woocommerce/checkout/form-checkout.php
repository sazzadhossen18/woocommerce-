<?php
/**
 * Checkout Form
 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}

?>





<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">











    <div class="row">


  <div class="col-lg-7 col-md-12">
       
  <?php if ( $checkout->get_checkout_fields() ) : ?>
    

  <div class="checkout-form box-shadow white-bg">
          <h4 class="mb-4 font-w-6">Billing Details</h4>
           <div class="row">
            <?php
    $fields = $checkout->get_checkout_fields( 'billing' );

    foreach ( $fields as $key => $field ) {
      woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
    }
    ?>
  



            
            <div class="col-md-6 sazzad">
              <div class="form-group">
                <label>First Name</label>
                <input type="text" id="billing_first_name" name="billing_first_name" class="form-control" placeholder="Your firstname">
              </div>
            </div>



            
            <div class="col-md-6">
              <div class="form-group">
                <label>Last Name</label>
                <input type="text" id="billing_last_name" name="billing_last_name" class="form-control" placeholder="Your lastname">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>E-mail Address</label>
                <input type="text" id="billing_email" name="billing_email" class="form-control" placeholder="State Province">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Phone Number</label>
                <input type="number" id="billing_phone" name="billing_phone" class="form-control" placeholder="">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Company Name</label>
                <input type="text" id="billing_company" name="billing_company" class="form-control" placeholder="Company Name">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Select Country</label>

                <select name="billing_country" id="billing_country" class="form-control select2">
                    <option value="#">Select country</option>
                    <option value="#">Alaska</option>
                    <option value="#">China</option>
                    <option value="#">Japan</option>
                    <option value="#">Korea</option>
                    <option value="#">Philippines</option>
                  </select>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Address</label>
                <input type="text" id="billing_address_1" name="billing_address_1" class="form-control" placeholder="Enter Your Address">
              </div>
              <div class="form-group">
                <input type="text" id="billing_address_2" name="billing_address_2" class="form-control" placeholder="Second Address">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Town/City</label>
                <input type="text" id="billing_city" name="billing_city" class="form-control" placeholder="Town or City">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mb-md-0">
                <label>State/Province</label>

                <input type="text" id="billing_state" name="billing_state" class="form-control" placeholder="State Province">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mb-md-0">
                <label>Zip/Postal Code</label>
                <input type="text" id="billing_postcode" name="billing_postcode" class="form-control" placeholder="Zip / Postal">
              </div>
            </div>



















          </div>
    </div>  
   
  <?php endif; ?>

   
   </div>


</form>

  








	<div class="col-lg-5 col-md-12 mt-5 mt-lg-0">
		<div class="border bg-light-4 p-3 p-lg-5">

        <div class="mb-7">
          <?php echo bbloomer_display_coupon_form_below_proceed_checkout();?>
  
        </div>


	
<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<div id="order_review" class="woocommerce-checkout-review-order">
		<?php do_action( 'woocommerce_checkout_order_review' ); ?>
	</div>

<?php do_action( 'woocommerce_checkout_after_order_review' );?>

	</div>
</div>

	</div>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

</div>




