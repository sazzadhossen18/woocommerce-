<?php

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

?>


<?php wc_get_template_part('template_parts/hero');?>

<!--body content start-->

<div class="page-content">

<section>
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-12 order-lg-1">
        


        <div class="row mb-4 align-items-center">
          <div class="col-md-5 mb-3 mb-md-0"> <span class="text-dark"><?php echo woocommerce_result_count();?></span>
          </div>


          
<div class="col-md-7 d-flex align-items-center justify-content-md-end">

  <div class="view-filter nav nav-tabs" id="nav-tab" role="tablist"> 
        
  <a class="active" id="nav-tab2" data-toggle="tab" href="#tab1-1" role="tab" aria-selected="true"><i class="las la-th-large"></i></a> 
                  <a class="" id="nav-tab1" data-toggle="tab" href="#tab1-2" role="tab" aria-selected="false"><i class="las la-bars"></i></a> 
      </div>







            <div class="view-filter"> 
          <?php echo ecom_woocommerce_catalog_page_ordering();?>
            </div>
            <?php echo woocommerce_catalog_ordering();?>
          </div>
        </div>

<div class="tab-content p-0" id="nav-tabContent">
     <div role="tabpanel" class="tab-pane fade show active" id="tab1-1">
                
        <?php
if ( woocommerce_product_loop() ) {

  /**
   * Hook: woocommerce_before_shop_loop.
   *
   * @hooked woocommerce_output_all_notices - 10
   * @hooked woocommerce_result_count - 20
   * @hooked woocommerce_catalog_ordering - 30
   */
  do_action( 'woocommerce_before_shop_loop' );

  woocommerce_product_loop_start();

  if ( wc_get_loop_prop( 'total' ) ) {
    while ( have_posts() ) {
      the_post();

      /**
       * Hook: woocommerce_shop_loop.
       */
      do_action( 'woocommerce_shop_loop' );

      wc_get_template_part( 'content', 'product' );



    }
  }

  woocommerce_product_loop_end();

  /**
   * Hook: woocommerce_after_shop_loop.
   *
   * @hooked woocommerce_pagination - 10
   */
  //do_action( 'woocommerce_after_shop_loop' );
} else {
  /**
   * Hook: woocommerce_no_products_found.
   *
   * @hooked wc_no_products_found - 10
   */
  do_action( 'woocommerce_no_products_found' );
}


?>

 </div>

<div role="tabpanel" class="tab-pane fade show" id="tab1-2">

<?php
if ( woocommerce_product_loop() ) {

  /**
   * Hook: woocommerce_before_shop_loop.
   *
   * @hooked woocommerce_output_all_notices - 10
   * @hooked woocommerce_result_count - 20
   * @hooked woocommerce_catalog_ordering - 30
   */
  do_action( 'woocommerce_before_shop_loop' );

  woocommerce_product_loop_start();

  if ( wc_get_loop_prop( 'total' ) ) {
    while ( have_posts() ) {
      the_post(); ?>


<div class="card product-list mb-5">
          <div class="row align-items-center">
            <div class="col-lg-4 col-md-5">
           <?php echo woocommerce_template_loop_product_thumbnail()?>
            </div>
            <div class="col-lg-8 col-md-7">
              <div class="card-info">
                <div class="card-body">
                  <div class="product-title"><a class="link-title" href="<?php the_permalink();?>"><?php the_title();?></a>
                  </div>
                  <div class="mt-1"> <span class="product-price text-pink"><del class="text-muted">$35.00</del> $25.00</span>
                    <div class="star-rating"><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>
                    </div>
                  </div>
                  <p class="mb-3 mt-2">Curabitur semper varius lectus sed consequat. Nam accumsan dapibus sem, sed lobortis nisi porta vitae</p>
                </div>
                <div class="card-footer bg-transparent border-0">
                  <div class="product-link d-flex align-items-center">
                    <button class="btn btn-compare mr-2" data-toggle="tooltip" data-placement="top" title="" type="button" data-original-title="Compare"><i class="las la-random"></i> 
                    </button>
                    <button class="btn btn-compare mr-2" data-toggle="tooltip" data-placement="top" title="" type="button" data-original-title="Compare"><i class="lar la-heart"></i>
                    </button>
                  <?php
   echo apply_filters(
  'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
  sprintf(
    '<a href="%s" class="btn-cart btn btn-pink mx-3" data-quantity="%s" class="%s" %s><i class="las la-shopping-cart mr-1"></i>%s</a>',

    esc_url( $product->add_to_cart_url() ),
    esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
    esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
    isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
    esc_html($product->add_to_cart_text() )
  ),
  $product,
  $args
);

?>
                   <?php echo do_shortcode('[yith_quick_view]')?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      
<?php
    }
  }

  woocommerce_product_loop_end();

  /**
   * Hook: woocommerce_after_shop_loop.
   *
   * @hooked woocommerce_pagination - 10
   */
  //do_action( 'woocommerce_after_shop_loop' );
}
?>
                    
    </div>              
</div>

 
    




    

  

       <?php echo ecom_pagination();?>
      </div>

      <div class="col-lg-3 col-md-12 sidebar mt-8 mt-lg-0">
        <?php do_action( 'woocommerce_sidebar' );  ?>
      </div>



    </div>
  </div>
</section>

</div>
<script>
  (function($){
    'use strict';

    $('.breadcrumb li a').addClass('link-title');
    $('.breadcrumb li:last-child').addClass('text-primary');
     $('.pagination li a').addClass('page-link');
    $('.pagination li span').addClass('page-link');
  })(jQuery);
</script>

<?php get_footer( 'shop' ); ?>

