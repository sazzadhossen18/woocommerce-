<?php
/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.8.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' ); ?>

<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
  <?php do_action( 'woocommerce_before_cart_table' ); ?>
<div class="page-content">

<section>
  <div class="container">
    <div class="row">

      <div class="col-lg-8">
        <div class="table-responsive">
          <table class="cart-table table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Total</th>
              </tr>
            </thead>





            
            <tbody>
      <?php
      foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
        $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

        if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
          $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
          ?>
          <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">














                <td>
                  <div class="cart-thumb media align-items-center">
                    <a href="#">
                      <img class="img-fluid" src="assets/images/product/p11.jpg" alt="">
                    </a>
                    <div class="media-body ml-3">
                      <div class="product-title mb-2"><a class="link-title" href="#">Unpaired Running Shoes</a>
                      </div>
                    </div>
                  </div>
                </td>
                <td> <span class="product-price text-muted">$68.00</span>
                </td>
                <td>


















                  <div class="d-flex align-items-center">
                  
            <td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woocommerce' ); ?>">

            <?php
            if ( $_product->is_sold_individually() ) {
              $product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
            } else {
              $product_quantity = woocommerce_quantity_input(
                array(
                  'input_name'   => "cart[{$cart_item_key}][qty]",
                  'input_value'  => $cart_item['quantity'],
                  'max_value'    => $_product->get_max_purchase_quantity(),
                  'min_value'    => '0',
                  'product_name' => $_product->get_name(),
                ),
                $_product,
                false
              );
            }

            echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // PHPCS: XSS ok.
            
            ?>
            </td>
                  </div>
                </td>
                <td> <span class="product-price text-dark font-w-6">$68.00</span>
                  <?php
    echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                  'woocommerce_cart_item_remove_link',
                  sprintf(
                    '<a href="%s" class="close-link" aria-label="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                    esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                    esc_html__( 'Remove this item', 'woocommerce' ),
                    esc_attr( $product_id ),
                    esc_attr( $_product->get_sku() )
                  ),
                  $cart_item_key
                );
              ?>

                </td>
              </tr>
              
              <?php
        }
      }
      ?>
            </tbody>
          </table>
        </div>
        
      </div>

      
      <div class="col-lg-4 pl-lg-5 mt-8 mt-lg-0">
        <div class="border rounded p-5 bg-light-4">
          <h4 class="text-black text-left mb-2 font-w-6">Cart Totals</h4>
          <div class="d-flex justify-content-between align-items-center border-bottom py-3"> <span class="text-muted">Subtotal</span>  <span class="text-dark"><?php wc_cart_totals_subtotal_html(); ?>.00</span> 
          </div>

<a href="#" class="item_remove"></a>

  <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
      <div class="d-flex justify-content-between align-items-center border-bottom py-3 cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
        <span class="text-muted"><?php wc_cart_totals_coupon_label( $coupon ); ?></span>
        <span class="text-dark" data-title="<?php echo esc_attr( wc_cart_totals_coupon_label( $coupon, false ) ); ?>">.00<?php wc_cart_totals_coupon_html( $coupon ); ?>
          
        </span>

      </div>
    <?php endforeach; ?>


                                                             
                    




          <div class="d-flex justify-content-between align-items-center pt-3 mb-5"> <span class="text-dark h5">Total</span>  <span class="text-dark font-w-6 h5"><?php wc_cart_totals_order_total_html(); ?>.00</span> 
          </div> <a class="btn btn-primary btn-animated btn-block" href="product-checkout.html">Proceed To Checkout</a>
          <a class="btn btn-dark btn-animated mt-3 btn-block" href="#">Continue Shopping</a>
        </div>
      </div>
    </div>
    <?php do_action( 'woocommerce_cart_contents' ); ?>
  <?php if ( wc_coupons_enabled() ) { ?>
    <div class="d-md-flex align-items-end justify-content-between py-5 px-5 mt-5 bg-light-4">
          <div>
            <label class="text-black h4" for="coupon">Coupon</label>
            <p>Enter your coupon code if you have one.</p>
            <div class="row form-row">
              <div class="col">
              <input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon Code', 'woocommerce' ); ?>" /> 
               
              </div>
              <div class="col col-auto">
                <button type="submit" class="btn btn-dark btn-animated" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>

              <?php do_action( 'woocommerce_cart_coupon' ); ?>
               
              </div>
            </div>
          </div>

            

          <button type="submit" class="btn btn-primary btn-animated mt-3 mt-md-0" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></button>

          <?php do_action( 'woocommerce_cart_actions' ); ?>

          <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
       

          
        </div>
        <?php do_action( 'woocommerce_after_cart_contents' ); ?>
    <?php } ?>


  </div>
</section>



</div>
 








  
  <?php do_action( 'woocommerce_after_cart_table' ); ?>

















 

   













</form>

<?php do_action( 'woocommerce_before_cart_collaterals' ); ?>



<div class="cart-collaterals">
  <?php
    /**
     * Cart collaterals hook.
     *
     * @hooked woocommerce_cross_sell_display
     * @hooked woocommerce_cart_totals - 10
     */
    //do_action( 'woocommerce_cart_collaterals' );
  ?>
</div>


<?php do_action( 'woocommerce_after_cart' ); ?>
