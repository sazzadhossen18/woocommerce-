<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>

<li <?php wc_product_class( '', $product ); ?>>


 <div class="card product-card card--default rounded-0">
   
    <a class="card-img-hover d-block" href="<?php the_permalink();?>">
  <?php echo woocommerce_template_loop_product_thumbnail()?>


    
 </a>
    <div class="card-icons">
    	
     <div class="card-icons__item"> 
     	<?php echo do_shortcode('[yith_quick_view]')?> 
     </div>

     
     <div class="card-icons__item"> 
     	<?php echo do_shortcode("[ti_wishlists_addtowishlist loop=yes]"); ?>

      </div>
</div>




        <div class="card-info">
                          <div class="card-body">
                            <div class="product-title font-w-5"><a class="link-title" href="product-left-image.html"><?php the_title();
                            bbloomer_show_sale_percentage_loop();


                            ?>
                            	
                            </a> 
                        </div>
                            <div class="mt-1">
                            	

 <span class="product-price text-pink">
 	<?php echo woocommerce_template_loop_price();?>
 <del class="text-muted"><?php echo get_woocommerce_currency_symbol();?><?php echo $product->get_regular_price(); ?>.00</del> <?php echo get_woocommerce_currency_symbol();?><?php echo $product->get_sale_price(); ?>.00
</span>




                              <div class="star-rating"><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i> </div>
                            </div>
                          </div>
                          <div class="card-footer bg-transparent border-0">
                            <div class="product-link d-flex align-items-center justify-content-center">
 <?php
   echo apply_filters(
	'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
	sprintf(
		'<a href="%s" class="btn-cart btn btn-pink mx-3" data-quantity="%s" class="%s" %s><i class="las la-shopping-cart mr-1"></i>%s</a>',

		esc_url( $product->add_to_cart_url() ),
		esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
		esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
		isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
		esc_html($product->add_to_cart_text() )
	),
	$product,
	$args
);

?>
                            </div>
                          </div>
                        </div>
                      </div>
      

 
           









	<?php

	/**
	 * Hook: woocommerce_before_shop_loop_item.
	 *
	 * @hooked woocommerce_template_loop_product_link_open - 10
	 */
	//do_action( 'woocommerce_before_shop_loop_item' );

	/**
	 * Hook: woocommerce_before_shop_loop_item_title.
	 *
	 * @hooked woocommerce_show_product_loop_sale_flash - 10
	 * @hooked woocommerce_template_loop_product_thumbnail - 10
	 */
	//do_action( 'woocommerce_before_shop_loop_item_title' );

	/**
	 * Hook: woocommerce_shop_loop_item_title.
	 *
	 * @hooked woocommerce_template_loop_product_title - 10
	 */
	//do_action( 'woocommerce_shop_loop_item_title' );

	/**
	 * Hook: woocommerce_after_shop_loop_item_title.
	 *
	 * @hooked woocommerce_template_loop_rating - 5
	 * @hooked woocommerce_template_loop_price - 10
	 */
	//do_action( 'woocommerce_after_shop_loop_item_title' );

	/**
	 * Hook: woocommerce_after_shop_loop_item.
	 *
	 * @hooked woocommerce_template_loop_product_link_close - 5
	 * @hooked woocommerce_template_loop_add_to_cart - 10
	 */
	//do_action( 'woocommerce_after_shop_loop_item' );
	?>



</li>
