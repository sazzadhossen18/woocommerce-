
<?php


Header::
=========

function register_custom_nav_menus() {

  register_nav_menus( array(
            'Header_menu' => esc_html__( 'Primary', 'nexus' ),
        ) );

  add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );


}
add_action( 'after_setup_theme', 'register_custom_nav_menus' );



  <?php
        wp_nav_menu(
            array(
      'theme_location' => 'Header_menu',
    'container_class'          => 'collapse navbar-collapse',

     'container_id'          => 'navbarNav',
      'menu_class'          => 'navbar-nav ml-auto mr-auto',
            )
        );?>
  

<?

function special_nav_class($classes, $item){
  $classes[] = 'nav-item dropdown';
  return $classes;
}
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 4);


function add_menu_atts($atts){
  $class = 'nav-link';
  $atts['class'] = $class;
  return $atts;
}
add_filter('nav_menu_link_attributes', 'add_menu_atts');

Active Menu::
============
============
 <script>
  (function($){
    'use strict';
$('div#navbarNav li.current-menu-item a').addClass('active');
  
  })(jQuery);
</script>


 $('.mainmenu li ul.submenu').parent('li').append('<span class="menu"><i class="fa fa-angle-down"></span>')

       <?php
        wp_nav_menu( array(
            'theme_location'  => 'Header_menu',
            'depth'             => 5,
            'container'         => 'div',
            'container_class'   => 'mainmenu',
          
            'menu_class'        => 'navigation',
            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
            'walker'            => new WP_Bootstrap_Navwalker(),
        ) );
        ?>


   
User Name display 
=================
=================
==================

<?php

// Check if user is logged in
if ( is_user_logged_in() ) {
    // Get current logged in user details
    $current_user = wp_get_current_user();
    echo $current_user->display_name;
} else {
    echo 'Not logged in';
}

?>


ul.dropdown-menu li.submenumenu-item a.dropdown-item{
   margin-left: -40px; 
   
}
ul.dropdown-menu li.submenumenu-item:hover a.dropdown-item:last-child {
  
    margin-left: -40px; 
     background-color:transparent; 
}

.dropdown-item {
    display: block;
    width: 100%;
    padding: .25rem 1.5rem;
    clear: both;
    font-weight: 400;
    color: #212529;
    text-align: inherit;
    white-space: nowrap;
     background-color:none; 
    border: 0;
}

.navbar .navbar-nav > li .dropdown-menu a {
    font-weight: 400;
    font-size: 0.9rem;
    position: relative;
    /* color: #71787d; */
}


<?php echo do_shortcode('[gtranslate]'); ?>


Cart Count::
===========
<?php echo WC()->cart->get_cart_contents_count(); ?>
<a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><?php WC()->cart->get_cart_contents_count(); ?></a>

Checkout Page url:
===================
===================
<?php echo wc_get_checkout_url();?>

User LogIn ::
=================
=================
=================
 <?php if ( is_user_logged_in() ) { ?>
  <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','woothemes'); ?>"><?php _e('Account','woothemes'); ?></a>
 <?php } 
 else { ?>
  <a class="mr-1 mr-sm-3" href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Login / Register','woothemes'); ?>"><?php _e('<i class="las la-user-alt"></i>','woothemes'); ?></a>
 <?php } ?>


wishlist count ::
=================
=================
=================


<a class="mr-3 d-none d-sm-inline" href="<?php echo esc_url( tinv_url_wishlist_default() ); ?>"><i class="lar la-heart"></i></a>
  
<?php echo WC()->cart->get_cart_contents_count(); ?>

<?php echo wc_cart_totals_subtotal_html();?>
<?php echo wc_get_cart_url(); ?>
<?php echo wc_get_checkout_url();?>


Mini Shop cart ::
=================
=================
=================
     <ul class="cart_list product_list_widget <?php echo esc_attr( $args['list_class'] ); ?>">
    <?php
    do_action( 'woocommerce_before_mini_cart_contents' );

    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
      $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
      $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

      if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
        $product_name      = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
        $thumbnail         = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
        $product_price     = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
        $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
        ?>
        <li class="item_remove <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key ) ); ?>">
          <?php
          echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            'woocommerce_cart_item_remove_link',
            sprintf(
              '<a href="%s" class="item_remove" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">&times;</a>',
              esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
              esc_attr__( 'Remove this item', 'woocommerce' ),
              esc_attr( $product_id ),
              esc_attr( $cart_item_key ),
              esc_attr( $_product->get_sku() )
            ),
            $cart_item_key
          );
          ?>
          <?php if ( empty( $product_permalink ) ) : ?>
            <?php echo $thumbnail . $product_name; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
          <?php else : ?>
            <a href="<?php echo esc_url( $product_permalink ); ?>">
              <?php echo $thumbnail . $product_name; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </a>
          <?php endif; ?>
          <?php echo wc_get_formatted_cart_item_data( $cart_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
          <?php echo apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="cart_quantity">' . sprintf( '%s &times; %s', $cart_item['quantity'], $product_price ) . '</span>', $cart_item, $cart_item_key ); //  ?>
        </li>
        <?php
      }
    }

    do_action( 'woocommerce_mini_cart_contents' );
    ?>
  </ul>
   <?php
      if( $show_count ):
        echo yith_wcwl_get_count_text( $product_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
      endif;
      ?>







 Custom Coupon Code::
 ======================
 ======================
 <?php
function bbloomer_display_coupon_form_below_proceed_checkout() {
   ?> 
      <form class="woocommerce-coupon-form" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" method="post">
         <?php if ( wc_coupons_enabled() ) { ?>
            <div class="coupon under-proceed">
               <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" style="width: 100%" /> 
               <button type="submit" class="button" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>" style="width: 100%"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>
            </div>
         <?php } ?>
      </form>
   <?php
}


add_action( 'woocommerce_proceed_to_checkout', 'bbloomer_display_coupon_form_below_proceed_checkout',);




Breadcrum::
=============
=============
<?php wc_get_template_part('template-parts/hero/hero');?>
function custom_woocommerce_breadcrumbs() {
    return array(
            'delimiter'   => ' ',
            'wrap_before' => ' <ol class="breadcrumb justify-content-md-end bg-transparent p-0 m-0">',
            'wrap_after'  => '</ol>',
            'before'      => '<li class="breadcrumb-item">',
            'after'       => '</li>',
            'home'        => _x( 'Home', 'breadcrumb', 'woocommerce' ),
        );
}
add_filter( 'woocommerce_breadcrumb_defaults', 'custom_woocommerce_breadcrumbs' );

<section class="bg-light py-6">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-6">
        <h1 class="h2 mb-0"><?php woocommerce_page_title();?></h1>
      </div>
      <div class="col-md-6 mt-3 mt-md-0">
        <nav aria-label="breadcrumb">
          <?php woocommerce_breadcrumb()?>
          
        </nav>
      </div>
    </div>
    <!-- / .row -->
  </div>
  <!-- / .container -->
</section>


<script>
  (function($){
    'use strict';
    $('.breadcrumb li a').addClass('link-title');
    $('.breadcrumb li:last-child').addClass('text-primary');
    
  })(jQuery);
</script>


                  Shop Page
================================================================================================================================================================================================


 <div class="row mb-4 align-items-center">
          <div class="col-md-5 mb-3 mb-md-0"> <span class="text-dark"><?php echo woocommerce_result_count();?></span>
          </div>
          <div class="col-md-7 d-flex align-items-center justify-content-md-end">
            <div class="view-filter"> 
          <?php echo ecom_woocommerce_catalog_page_ordering();?>
            </div>
            <?php echo woocommerce_catalog_ordering();?>
          </div>
        </div>

   
Sidebar Category ::
==================

<?php

function woocommerce_subcats_from_parentcat_by_NAME() {

        $taxonomy = 'product_cat';
        $orderby = 'name';
        $show_count = 0;
        $pad_counts = 0;
        $hierarchical = 1;

   $args = array(
    'show_count' => $show_count,
       'orderby' => $orderby,
       'taxonomy' => $taxonomy,
       'hierarchical' => $hierarchical,
       'pad_counts' => $pad_counts    
   );

$all_categories = get_categories($args);
foreach ($all_categories as $cat) {

    if ($cat->category_parent == 0) {
       $category_id = $cat->term_id;
       $thumbnail_id = get_term_meta($cat->term_id,'thumbnail_id',true);
       $image = wp_get_attachment_url($thumbnail_id);

       echo "<div class='card border-0 mb-2'><div class='card-header'><h6 class='mb-0'>
            <a class='link-title' data-toggle='collapse' id='collapse".$category_id."' href='#collapse".$category_id."'>".$cat->name;

       echo '</a></h6></div>'; 
       echo "<div class='collapse".$category_id."'>
                  <div class='card-body text-muted'>
                    <ul class='list-unstyled'>"; 

                    ?>

    <script>
  (function($){
    'use strict';

    $('.collapse<?php echo $category_id;?>').hide();
    $('#collapse<?php echo $category_id;?>').click(function(){
        $('#collapse<?php echo $category_id;?>').css('color','red')
        $('.collapse<?php echo $category_id;?>').slideDown(500);

    });


  })(jQuery);
</script>


    <?php


        $args2 = array(
       'orderby' => $orderby,
       'taxonomy' => $taxonomy,
       'show_count' => $show_count,
       'child_of'  => 0,
       'parent'    => $category_id,
       'hierarchical' => $hierarchical,
       'pad_counts' => $pad_counts

       
   );
        $sub_cats = get_categories($args2);
       if ($sub_cats) {
            foreach ($sub_cats as $sub_category) {

            echo '<li><a href="'.get_term_link( $sub_category ).'">'.$sub_category->cat_name;
            echo "</a></li>";

           
        }
       }

        echo "</ul> </div></div>";
                 
    echo "</div>";

    }

     }

}



product per page show dorpdown:: 
==================================
==================================
function ecom_woocommerce_catalog_page_ordering() {
?>

<?php echo '<div class="sort-filter ml-2 d-flex align-items-center show_per_page">' ?>
    <form action="" method="POST" name="results" class="woocommerce-ordering">
    <select name="woocommerce-sort-by-columns" id="woocommerce-sort-by-columns" class="custom-select" onchange="this.form.submit()">
<?php
 
//Get products on page reload
if  (isset($_POST['woocommerce-sort-by-columns']) && (($_COOKIE['shop_pageResults'] <> $_POST['woocommerce-sort-by-columns']))) {
        $numberOfProductsPerPage = $_POST['woocommerce-sort-by-columns'];
          } else {
        $numberOfProductsPerPage = $_COOKIE['shop_pageResults'];
          }
 
//  This is where you can change the amounts per page that the user will use  feel free to change the numbers and text as you want, in my case we had 4 products per row so I chose to have multiples of four for the user to select.
            $shopCatalog_orderby = apply_filters('woocommerce_sortby_page', array(
            //Add as many of these as you like, -1 shows all products per page
              //  ''       => __('Results per page', 'woocommerce'),
                ''       => __('Results per page', 'woocommerce'),
                '5'        => __('5', 'woocommerce'),
                '10'        => __('10', 'woocommerce'),
                '15'        => __('15', 'woocommerce'),
                '20'        => __('20', 'woocommerce'),
                '-1'        => __('All', 'woocommerce'),
            ));

        foreach ( $shopCatalog_orderby as $sort_id => $sort_name )
            echo '<option value="' . $sort_id . '" ' . selected( $numberOfProductsPerPage, $sort_id, true ) . ' >' . $sort_name . '</option>';
?>
</select>
</form>

<?php echo '</div>' ?>
<?php
}
 
// now we set our cookie if we need to
function dl_sort_by_page($count) {
  if (isset($_COOKIE['shop_pageResults'])) { // if normal page load with cookie
     $count = $_COOKIE['shop_pageResults'];
  }
  if (isset($_POST['woocommerce-sort-by-columns'])) { //if form submitted
    setcookie('shop_pageResults', $_POST['woocommerce-sort-by-columns'], time()+1209600, '/', 'www.your-domain-goes-here.com', false); //this will fail if any part of page has been output- hope this works!
    $count = $_POST['woocommerce-sort-by-columns'];
  }
  // else normal page load and no cookie
  return $count;
}
 
add_filter('loop_shop_per_page','dl_sort_by_page');





Output-the-product-sorting-options::
==================================
==================================
 
    function woocommerce_catalog_ordering() {
        if ( ! wc_get_loop_prop( 'is_paginated' ) || ! woocommerce_products_will_display() ) {
            return;
        }
        $show_default_orderby    = 'menu_order' === apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby', 'menu_order' ) );
        $catalog_orderby_options = apply_filters(
            'woocommerce_catalog_orderby',
            array(
                'menu_order' => __( 'Default sorting', 'woocommerce' ),
                 'date'       => __( 'Newes Latest', 'woocommerce' ),
                'popularity' => __( 'Popularity', 'woocommerce' ),         
                'price'      => __( 'Low to high', 'woocommerce' ),
                'price-desc' => __( 'High to low', 'woocommerce' ),
            )
        );

        $default_orderby = wc_get_loop_prop( 'is_search' ) ? 'relevance' : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby', '' ) );
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $orderby = isset( $_GET['orderby'] ) ? wc_clean( wp_unslash( $_GET['orderby'] ) ) : $default_orderby;
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ( wc_get_loop_prop( 'is_search' ) ) {
            $catalog_orderby_options = array_merge( array( 'relevance' => __( 'Relevance', 'woocommerce' ) ), $catalog_orderby_options );

            unset( $catalog_orderby_options['menu_order'] );
        }

        if ( ! $show_default_orderby ) {
            unset( $catalog_orderby_options['menu_order'] );
        }

        if ( ! wc_review_ratings_enabled() ) {
            unset( $catalog_orderby_options['rating'] );
        }

        if ( ! array_key_exists( $orderby, $catalog_orderby_options ) ) {
            $orderby = current( array_keys( $catalog_orderby_options ) );
        }

        wc_get_template(
            'loop/orderby.php',
            array(
                'catalog_orderby_options' => $catalog_orderby_options,
                'orderby'                 => $orderby,
                'show_default_orderby'    => $show_default_orderby,
            )
        );
    }


?>

loop/orderby.php
===========================
===========================
<div class="sort-filter ml-2 d-flex align-items-center">
<form class="woocommerce-ordering" method="get">
  <select name="orderby" class="orderby custom-select" aria-label="<?php esc_attr_e( 'Shop order', 'woocommerce' ); ?>">
    <?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
      <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
    <?php endforeach; ?>
  </select>
  <input type="hidden" name="paged" value="1" />
  <?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
</form>
</div>


Pagination::


<script>
  (function($){
    'use strict';

    $('.breadcrumb li a').addClass('link-title');
    $('.breadcrumb li:last-child').addClass('text-primary');
     $('.pagination li a').addClass('page-link');
    $('.pagination li span').addClass('page-link');
  })(jQuery);
</script>



 wordpress custom pagination:
 ===========================
 ===========================
 <?php
function ecom_pagination(){
  global $wp_query;

  if ( $wp_query->max_num_pages <= 1 ) return; 

  $big = 999999999; // need an unlikely integer

  $pages = paginate_links( array(
      'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
      'format'    => '?paged=%#%',
      'current'   => max( 1, get_query_var('paged') ),
      'total'     => $wp_query->max_num_pages,
      'type'      => 'array',
      'prev_next' => true,
    'prev_text' => __('Previous'),
    'next_text' => __('Next'),
  ) );
  
  if( is_array( $pages ) ) {
      $paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
      echo '<nav aria-label="Page navigation">
          <ul class="shop-page pagination justify-content-end">';
      foreach ( $pages as $page ) {
              echo "<li class='page-item'>$page</li>";
      }
     echo '</ul></nav>';
    }
}



 Sidebar::
=============
=============

  <div class="col-lg-3 col-md-12 sidebar mt-8 mt-lg-0">
        <?php do_action( 'woocommerce_sidebar' );  ?>
  </div>




  Grid/List View::
==================
==================
 <div class="view-filter nav nav-tabs" id="nav-tab" role="tablist">
      <a class="sazzad active" id="nav-tab2" data-toggle="tab" href="#tab1-1" role="tab" aria-selected="true"><i class="las la-th-large"></i></a> 
      <a class="sazzad" id="nav-tab1" data-toggle="tab" href="#tab1-2" role="tab" aria-selected="false"><i class="las la-bars"></i></a> 
</div>

<div class="tab-content p-0" id="nav-tabContent">
    <div role="tabpanel" class="tab-pane fade show active" id="tab1-1">
   Code Here
    </div>

    <div role="tabpanel" class="tab-pane fade show" id="tab1-2">
   Code Here
    </div>
</div>


Example::
========

<div class="tab-content p-0" id="nav-tabContent">
     <div role="tabpanel" class="tab-pane fade show active" id="tab1-1">
                
        <?php
if ( woocommerce_product_loop() ) {

  /**
   * Hook: woocommerce_before_shop_loop.
   *
   * @hooked woocommerce_output_all_notices - 10
   * @hooked woocommerce_result_count - 20
   * @hooked woocommerce_catalog_ordering - 30
   */
  do_action( 'woocommerce_before_shop_loop' );

  woocommerce_product_loop_start();

  if ( wc_get_loop_prop( 'total' ) ) {
    while ( have_posts() ) {
      the_post();

      /**
       * Hook: woocommerce_shop_loop.
       */
      do_action( 'woocommerce_shop_loop' );

      wc_get_template_part( 'content', 'product' );



    }
  }

  woocommerce_product_loop_end();

  /**
   * Hook: woocommerce_after_shop_loop.
   *
   * @hooked woocommerce_pagination - 10
   */
  //do_action( 'woocommerce_after_shop_loop' );
} else {
  /**
   * Hook: woocommerce_no_products_found.
   *
   * @hooked wc_no_products_found - 10
   */
  do_action( 'woocommerce_no_products_found' );
}


?>

 </div>

<div role="tabpanel" class="tab-pane fade show" id="tab1-2">

<?php
if ( woocommerce_product_loop() ) {

  /**
   * Hook: woocommerce_before_shop_loop.
   *
   * @hooked woocommerce_output_all_notices - 10
   * @hooked woocommerce_result_count - 20
   * @hooked woocommerce_catalog_ordering - 30
   */
  do_action( 'woocommerce_before_shop_loop' );

  woocommerce_product_loop_start();

  if ( wc_get_loop_prop( 'total' ) ) {
    while ( have_posts() ) {
      the_post(); ?>


<div class="card product-list mb-5">
          <div class="row align-items-center">
            <div class="col-lg-4 col-md-5">
           <?php echo woocommerce_template_loop_product_thumbnail()?>
            </div>
            <div class="col-lg-8 col-md-7">
              <div class="card-info">
                <div class="card-body">
                  <div class="product-title"><a class="link-title" href="<?php the_permalink();?>"><?php the_title();?></a>
                  </div>
                  <div class="mt-1"> <span class="product-price text-pink"><del class="text-muted">$35.00</del> $25.00</span>
                    <div class="star-rating"><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>
                    </div>
                  </div>
                  <p class="mb-3 mt-2">Curabitur semper varius lectus sed consequat. Nam accumsan dapibus sem, sed lobortis nisi porta vitae</p>
                </div>
                <div class="card-footer bg-transparent border-0">
                  <div class="product-link d-flex align-items-center">
                    <button class="btn btn-compare mr-2" data-toggle="tooltip" data-placement="top" title="" type="button" data-original-title="Compare"><i class="las la-random"></i> 
                    </button>
                    <button class="btn btn-compare mr-2" data-toggle="tooltip" data-placement="top" title="" type="button" data-original-title="Compare"><i class="lar la-heart"></i>
                    </button>
                  <?php
   echo apply_filters(
  'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
  sprintf(
    '<a href="%s" class="btn-cart btn btn-pink mx-3" data-quantity="%s" class="%s" %s><i class="las la-shopping-cart mr-1"></i>%s</a>',

    esc_url( $product->add_to_cart_url() ),
    esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
    esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
    isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
    esc_html($product->add_to_cart_text() )
  ),
  $product,
  $args
);

?>
                   <?php echo do_shortcode('[yith_quick_view]')?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      
<?php
    }
  }

  woocommerce_product_loop_end();

  /**
   * Hook: woocommerce_after_shop_loop.
   *
   * @hooked woocommerce_pagination - 10
   */
  //do_action( 'woocommerce_after_shop_loop' );
}
?>
                    
    </div>              
</div>










Archive.php::
===============
===============
===============
<?php

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

?>


<?php wc_get_template_part('template_parts/hero');?>

<!--body content start-->

<div class="page-content">

<section>
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-12 order-lg-1">
        


        <div class="row mb-4 align-items-center">
          <div class="col-md-5 mb-3 mb-md-0"> <span class="text-dark"><?php echo woocommerce_result_count();?></span>
          </div>
          <div class="col-md-7 d-flex align-items-center justify-content-md-end">
            <div class="view-filter"> 
          <?php echo ecom_woocommerce_catalog_page_ordering();?>
            </div>
            <?php echo woocommerce_catalog_ordering();?>
          </div>
        </div>


        <?php
if ( woocommerce_product_loop() ) {

  /**
   * Hook: woocommerce_before_shop_loop.
   *
   * @hooked woocommerce_output_all_notices - 10
   * @hooked woocommerce_result_count - 20
   * @hooked woocommerce_catalog_ordering - 30
   */
  do_action( 'woocommerce_before_shop_loop' );

  woocommerce_product_loop_start();

  if ( wc_get_loop_prop( 'total' ) ) {
    while ( have_posts() ) {
      the_post();

      /**
       * Hook: woocommerce_shop_loop.
       */
      do_action( 'woocommerce_shop_loop' );

      wc_get_template_part( 'content', 'product' );
    }
  }

  woocommerce_product_loop_end();

  /**
   * Hook: woocommerce_after_shop_loop.
   *
   * @hooked woocommerce_pagination - 10
   */
  //do_action( 'woocommerce_after_shop_loop' );
} else {
  /**
   * Hook: woocommerce_no_products_found.
   *
   * @hooked wc_no_products_found - 10
   */
  do_action( 'woocommerce_no_products_found' );
}


?>

    

  

       <?php echo ecom_pagination();?>
      </div>

      <div class="col-lg-3 col-md-12 sidebar mt-8 mt-lg-0">
        <?php do_action( 'woocommerce_sidebar' );  ?>
      </div>



    </div>
  </div>
</section>

</div>
<script>
  (function($){
    'use strict';

    $('.breadcrumb li a').addClass('link-title');
    $('.breadcrumb li:last-child').addClass('text-primary');
     $('.pagination li a').addClass('page-link');
    $('.pagination li span').addClass('page-link');
  })(jQuery);
</script>

<?php get_footer( 'shop' ); ?>









<!--body content end--> 

<?php get_footer( 'shop' ); ?>


<?php the_permalink();?>
 <?php the_post_thumbnail('feature-image', array('class' => 'card-img-back')); ?>
<?php the_post_thumbnail(); ?>
<?php echo get_woocommerce_currency_symbol();?><?php echo $product->get_regular_price(); ?>.00
<?php echo get_woocommerce_currency_symbol();?><?php echo $product->get_sale_price(); ?>.00

Button
..................

 <?php
   echo apply_filters(
	'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
	sprintf(
		'<button href="%s" class="btn-cart btn btn-pink mx-3" data-quantity="%s" class="%s" %s><i class="las la-shopping-cart mr-1"></i>%s</button>',

		esc_url( $product->add_to_cart_url() ),
		esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
		esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
		isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
		esc_html($product->add_to_cart_text() )
	),
	$product,
	$args
);

?>


================================================================        
================================================================
                Shop Page End 
================================================================================================================================  













================================================================				
================================================================
  Cart Page
================================================================================================================================  


Mini Cart:
           
                      <ul class="cart_list product_list_widget <?php echo esc_attr( $args['list_class'] ); ?>">
    <?php
    do_action( 'woocommerce_before_mini_cart_contents' );

    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
      $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
      $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

      if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
        $product_name      = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
        $thumbnail         = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
        $product_price     = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
        $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
        ?>
        <li class="item_remove <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key ) ); ?>">
          <?php
          echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            'woocommerce_cart_item_remove_link',
            sprintf(
              '<a href="%s" class="item_remove" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">&times;</a>',
              esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
              esc_attr__( 'Remove this item', 'woocommerce' ),
              esc_attr( $product_id ),
              esc_attr( $cart_item_key ),
              esc_attr( $_product->get_sku() )
            ),
            $cart_item_key
          );
          ?>
          <?php if ( empty( $product_permalink ) ) : ?>
            <?php echo $thumbnail . $product_name; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
          <?php else : ?>
            <a href="<?php echo esc_url( $product_permalink ); ?>">
              <?php echo $thumbnail . $product_name; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </a>
          <?php endif; ?>
          <?php echo wc_get_formatted_cart_item_data( $cart_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
          <?php echo apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="cart_quantity">' . sprintf( '%s &times; %s', $cart_item['quantity'], $product_price ) . '</span>', $cart_item, $cart_item_key ); //  ?>
        </li>
        <?php
      }
    }

    do_action( 'woocommerce_mini_cart_contents' );
    ?>
  </ul>






<?php 
/*
Template Name: cart
*/

get_header();
 
?>

  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
   <?php the_content();?>
  <?php endwhile; endif;?>


<?php get_footer();?>

<?php echo home_url( '/' );?>

<?php echo esc_url(get_permalink(woocommerce_get_page_id('shop'))); ?>




 <?php
			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
				$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

				if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
					$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
					?>



---------code--------------------

<?php
				}
			}
			?>


image:
============================================================

   <?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );

						if ( ! $product_permalink ) {
							echo $thumbnail; // PHPCS: XSS ok.
						} else {
							printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail ); // PHPCS: XSS ok.
						}
						?> 


img.attachment-woocommerce_thumbnail.size-woocommerce_thumbnail {

width:100px;

}

 Title:
 ============================================================
         <?php
            if ( ! $product_permalink ) {
              echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' );
            } else {
              echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_name() ), $cart_item, $cart_item_key ) );
            }

            do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

            // Meta data.
            echo wc_get_formatted_cart_item_data( $cart_item ); // PHPCS: XSS ok.

            // Backorder notification.
            if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
              echo wp_kses_post( apply_filters( 'woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'woocommerce' ) . '</p>', $product_id ) );
            }
            ?>

Price:
============================================================


  <?php
		echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
		?>




Quantity:
============================================================

  <?php
            if ( $_product->is_sold_individually() ) {
              $product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
            } else {
              $product_quantity = woocommerce_quantity_input(
                array(
                  'input_name'   => "cart[{$cart_item_key}][qty]",
                  'input_value'  => $cart_item['quantity'],
                  'max_value'    => $_product->get_max_purchase_quantity(),
                  'min_value'    => '0',
                  'product_name' => $_product->get_name(),
                ),
                $_product,
                false
              );
            }

            echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // PHPCS: XSS ok.
  ?>









subtotal:
============================================================

    <?php
                echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
              ?>

Remve:
============================================================

     <?php
    echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                  'woocommerce_cart_item_remove_link',
                  sprintf(
                    '<a href="%s" class="close-link" aria-label="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                    esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                    esc_html__( 'Remove this item', 'woocommerce' ),
                    esc_attr( $product_id ),
                    esc_attr( $_product->get_sku() )
                  ),
                  $cart_item_key
                );
              ?>





 SubTotal:
============================================================

 	<?php
   echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key); 
              ?>.00        

<?php wc_cart_totals_subtotal_html(); ?>.00

<?php wc_cart_totals_taxes_total_html(); ?>.00<

<?php wc_cart_totals_order_total_html(); ?>.00

coupon:
============================================================

  <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
      <div class="d-flex justify-content-between align-items-center border-bottom py-3 cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
        <span class="text-muted"><?php wc_cart_totals_coupon_label( $coupon ); ?></span>
        <span class="text-dark" data-title="<?php echo esc_attr( wc_cart_totals_coupon_label( $coupon, false ) ); ?>">.00<?php wc_cart_totals_coupon_html( $coupon ); ?>
          
        </span>

      </div>
    <?php endforeach; ?>


   <?php do_action( 'woocommerce_cart_contents' ); ?>
  <?php if ( wc_coupons_enabled() ) { ?>
    <div class="d-md-flex align-items-end justify-content-between py-5 px-5 mt-5 bg-light-4">
          <div>
            <label class="text-black h4" for="coupon">Coupon</label>
            <p>Enter your coupon code if you have one.</p>
            <div class="row form-row">
              <div class="col">
              <input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon Code', 'woocommerce' ); ?>" /> 
               
              </div>
              <div class="col col-auto">
                <button type="submit" class="btn btn-dark btn-animated" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>

              <?php do_action( 'woocommerce_cart_coupon' ); ?>

<button type="submit" class="btn btn-dark btn-animated" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>

<?php do_action( 'woocommerce_cart_coupon' ); ?>

          <button type="submit" class="btn btn-primary btn-animated mt-3 mt-md-0" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></button>



 car message ::

 
function wc_empty_cart_message() {
  echo '<p class="cart-empty woocommerce-info">' . wp_kses_post( apply_filters( 'wc_empty_cart_message', __( 'Your cart is currently empty.', 'woocommerce' ) ) ) . '</p>';
}





Example:
============================================================
<?php
/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.8.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' ); ?>

<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
  <?php do_action( 'woocommerce_before_cart_table' ); ?>
<div class="page-content">

<section>
  <div class="container">
    <div class="row">

      <div class="col-lg-8">
        <div class="table-responsive">
          <table class="cart-table table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
      <?php
      foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
        $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

        if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
          $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
          ?>
          <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">














                <td>
                  <div class="cart-thumb media align-items-center">
                    <a href="#">
                      <img class="img-fluid" src="assets/images/product/p11.jpg" alt="">
                    </a>
                    <div class="media-body ml-3">
                      <div class="product-title mb-2"><a class="link-title" href="#">Unpaired Running Shoes</a>
                      </div>
                    </div>
                  </div>
                </td>
                <td> <span class="product-price text-muted">$68.00</span>
                </td>
                <td>


















                  <div class="d-flex align-items-center">
                  
            <td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woocommerce' ); ?>">

            <?php
            if ( $_product->is_sold_individually() ) {
              $product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
            } else {
              $product_quantity = woocommerce_quantity_input(
                array(
                  'input_name'   => "cart[{$cart_item_key}][qty]",
                  'input_value'  => $cart_item['quantity'],
                  'max_value'    => $_product->get_max_purchase_quantity(),
                  'min_value'    => '0',
                  'product_name' => $_product->get_name(),
                ),
                $_product,
                false
              );
            }

            echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // PHPCS: XSS ok.
            ?>
            </td>
                  </div>
                </td>
                <td> <span class="product-price text-dark font-w-6">$68.00</span>
                  <?php
    echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                  'woocommerce_cart_item_remove_link',
                  sprintf(
                    '<a href="%s" class="close-link" aria-label="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                    esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                    esc_html__( 'Remove this item', 'woocommerce' ),
                    esc_attr( $product_id ),
                    esc_attr( $_product->get_sku() )
                  ),
                  $cart_item_key
                );
              ?>

                </td>
              </tr>
              
              <?php
        }
      }
      ?>
            </tbody>
          </table>
        </div>
        
      </div>

      
      <div class="col-lg-4 pl-lg-5 mt-8 mt-lg-0">
        <div class="border rounded p-5 bg-light-4">
          <h4 class="text-black text-left mb-2 font-w-6">Cart Totals</h4>
          <div class="d-flex justify-content-between align-items-center border-bottom py-3"> <span class="text-muted">Subtotal</span>  <span class="text-dark"><?php wc_cart_totals_subtotal_html(); ?>.00</span> 
          </div>



  <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
      <div class="d-flex justify-content-between align-items-center border-bottom py-3 cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
        <span class="text-muted"><?php wc_cart_totals_coupon_label( $coupon ); ?></span>
        <span class="text-dark" data-title="<?php echo esc_attr( wc_cart_totals_coupon_label( $coupon, false ) ); ?>">.00<?php wc_cart_totals_coupon_html( $coupon ); ?>
          
        </span>

      </div>
    <?php endforeach; ?>




  <div class="d-flex justify-content-between align-items-center border-bottom py-3"> <span class="text-muted">Tax</span>  <span class="text-dark"><?php wc_cart_totals_taxes_total_html(); ?>.00</span> 
  </div>




          <div class="d-flex justify-content-between align-items-center pt-3 mb-5"> <span class="text-dark h5">Total</span>  <span class="text-dark font-w-6 h5"><?php wc_cart_totals_order_total_html(); ?>.00</span> 
          </div> <a class="btn btn-primary btn-animated btn-block" href="product-checkout.html">Proceed To Checkout</a>
          <a class="btn btn-dark btn-animated mt-3 btn-block" href="#">Continue Shopping</a>
        </div>
      </div>
    </div>
    <?php do_action( 'woocommerce_cart_contents' ); ?>
  <?php if ( wc_coupons_enabled() ) { ?>
    <div class="d-md-flex align-items-end justify-content-between py-5 px-5 mt-5 bg-light-4">
          <div>
            <label class="text-black h4" for="coupon">Coupon</label>
            <p>Enter your coupon code if you have one.</p>
            <div class="row form-row">
              <div class="col">
              <input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon Code', 'woocommerce' ); ?>" /> 
               
              </div>
              <div class="col col-auto">
                <button type="submit" class="btn btn-dark btn-animated" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>

              <?php do_action( 'woocommerce_cart_coupon' ); ?>
               
              </div>
            </div>
          </div>

            

          <button type="submit" class="btn btn-primary btn-animated mt-3 mt-md-0" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></button>

          <?php do_action( 'woocommerce_cart_actions' ); ?>

          <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
       

          
        </div>
        <?php do_action( 'woocommerce_after_cart_contents' ); ?>
    <?php } ?>


  </div>
</section>



</div>
 
  <?php do_action( 'woocommerce_after_cart_table' ); ?>

</form>

<?php do_action( 'woocommerce_before_cart_collaterals' ); ?>

<div class="cart-collaterals">
  <?php
    /**
     * Cart collaterals hook.
     *
     * @hooked woocommerce_cross_sell_display
     * @hooked woocommerce_cart_totals - 10
     */
    //do_action( 'woocommerce_cart_collaterals' );
  ?>
</div>

<?php do_action( 'woocommerce_after_cart' ); ?>


================================================================================================================================================================
       Shop  Page  end
=================================================================================================================================================================================
















                     
================================================================================================================================================================
        Checkout Page 
==========================================================================================================================================================================================

<?
 //Custom Coupon Code
function bbloomer_display_coupon_form_below_proceed_checkout() {
   ?> 

      <form class="" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" method="post">
         <?php if ( wc_coupons_enabled() ) { ?>
            <label class="text-black mb-3">Enter your coupon code if you have one</label>
            <div class="input-group">
               <input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>"/>
               <div class="input-group-append"> 
               <button type="submit" class="btn btn-primary btn-sm px-4" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>
                </div>
            </div>
         <?php } ?>
      </form>
   <?php
}


add_action( 'woocommerce_proceed_to_checkout', 'bbloomer_display_coupon_form_below_proceed_checkout',);

    <div class="mb-7">
  <?php echo bbloomer_display_coupon_form_below_proceed_checkout();?>
  
        </div>


Your Order:
==========
 <?php
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
      $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );

      if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
        ?>

        .....................................


    <?php
      }
    }
    ?>    


Product:
=======

<?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;';?>

qty:
  <?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <span>' . sprintf( '&times;&nbsp;%s', $cart_item['quantity'] ) . '</span>', $cart_item, $cart_item_key ); ?>
            <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>


price:
<?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );  ?>.00

 subtotal:
 <?php wc_cart_totals_subtotal_html(); ?>


total:

<?php wc_cart_totals_order_total_html(); ?>

Coupon:

    <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
      <li class="mb-3 border-bottom pb-3 d-flex coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
        <th><?php wc_cart_totals_coupon_label( $coupon ); ?></th>
        <td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
      </li>
    <?php endforeach; ?>



Payment Method:
==============

<?php

defined( 'ABSPATH' ) || exit;

if ( ! is_ajax() ) {
  do_action( 'woocommerce_review_order_before_payment' );
}
?>



<div  class="cart-detail my-5">
  <h6 class="mb-3 font-w-6">Payment Method</h6>
  <?php if ( WC()->cart->needs_payment() ) : ?>
    <ul class="wc_payment_methods payment_methods methods">
      <?php
      if ( ! empty( $available_gateways ) ) {
        foreach ( $available_gateways as $gateway ) {
          wc_get_template( 'checkout/payment-method.php', array( 'gateway' => $gateway ) );
        }
      } else {
        echo '<li class="woocommerce-notice woocommerce-notice--info woocommerce-info">' . apply_filters( 'woocommerce_no_available_payment_methods_message', WC()->customer->get_billing_country() ? esc_html__( 'Sorry, it seems that there are no available payment methods for your state. Please contact us if you require assistance or wish to make alternate arrangements.', 'woocommerce' ) : esc_html__( 'Please fill in your details above to see available payment methods.', 'woocommerce' ) ) . '</li>'; // @codingStandardsIgnoreLine
      }
      ?>
    </ul>
  <?php endif; ?>
  <div class="form-row place-order">
    <noscript>
      <?php
      /* translators: $1 and $2 opening and closing emphasis tags respectively */
      printf( esc_html__( 'Since your browser does not support JavaScript, or it is disabled, please ensure you click the %1$sUpdate Totals%2$s button before placing your order. You may be charged more than the amount stated above if you fail to do so.', 'woocommerce' ), '<em>', '</em>' );
      ?>
      <br/><button type="submit" class="button alt" name="woocommerce_checkout_update_totals" value="<?php esc_attr_e( 'Update totals', 'woocommerce' ); ?>"><?php esc_html_e( 'Update totals', 'woocommerce' ); ?></button>
    </noscript>

    <?php wc_get_template( 'checkout/terms.php' ); ?>

    <?php do_action( 'woocommerce_review_order_before_submit' ); ?>

    <?php echo apply_filters( 'woocommerce_order_button_html', '<button type="submit" class="btn btn-primary btn-animated btn-block" name="woocommerce_checkout_place_order" id="place_order" value="' . esc_attr( $order_button_text ) . '" data-value="' . esc_attr( $order_button_text ) . '">' . esc_html( $order_button_text ) . '</button>' ); // @codingStandardsIgnoreLine ?>

    <?php do_action( 'woocommerce_review_order_after_submit' ); ?>

    <?php wp_nonce_field( 'woocommerce-process_checkout', 'woocommerce-process-checkout-nonce' ); ?>
  </div>
</div>
<?php
if ( ! is_ajax() ) {
  do_action( 'woocommerce_review_order_after_payment' );
}










<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}
?>
<div class="form-group payment_method_<?php echo esc_attr( $gateway->id ); ?>">
<div class="custom-control custom-radio">
  <input id="payment_method_<?php echo esc_attr( $gateway->id ); ?>" type="radio" class="input-radio custom-control-input" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?> data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>" />

  <label class="custom-control-label" for="payment_method_<?php echo esc_attr( $gateway->id ); ?>">
    <?php echo $gateway->get_title(); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?> <?php echo $gateway->get_icon(); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?>
  </label>
    
</div>
</div>













Checkout Form: 
===============
<?php
if ( ! function_exists( 'woocommerce_form_field' ) ) {

  /**
   * Outputs a checkout/address form field.
   *
   * @param string $key Key.
   * @param mixed  $args Arguments.
   * @param string $value (default: null).
   * @return string
   */
  function woocommerce_form_field( $key, $args, $value = null ) {
    $defaults = array(
      'type'              => 'text',
      'label'             => '',
      'description'       => '',
      'placeholder'       => '',
      'maxlength'         => false,
      'required'          => false,
      'autocomplete'      => false,
      'id'                => $key,
      'class'             => array(),
      'label_class'       => array(),
      'input_class'       => array(),
      'return'            => false,
      'options'           => array(),
      'custom_attributes' => array(),
      'validate'          => array(),
      'default'           => '',
      'autofocus'         => '',
      'priority'          => '',
    );

    $args = wp_parse_args( $args, $defaults );
    $args = apply_filters( 'woocommerce_form_field_args', $args, $key, $value );

    if ( $args['required'] ) {
      $args['class'][] = 'validate-required';
      $required        = '&nbsp;<abbr class="required" title="' . esc_attr__( 'required', 'woocommerce' ) . '">*</abbr>';
    } else {
      $required = '&nbsp;<span class="optional">(' . esc_html__( 'optional', 'woocommerce' ) . ')</span>';
    }

    if ( is_string( $args['label_class'] ) ) {
      $args['label_class'] = array( $args['label_class'] );
    }

    if ( is_null( $value ) ) {
      $value = $args['default'];
    }

    // Custom attribute handling.
    $custom_attributes         = array();
    $args['custom_attributes'] = array_filter( (array) $args['custom_attributes'], 'strlen' );

    if ( $args['maxlength'] ) {
      $args['custom_attributes']['maxlength'] = absint( $args['maxlength'] );
    }

    if ( ! empty( $args['autocomplete'] ) ) {
      $args['custom_attributes']['autocomplete'] = $args['autocomplete'];
    }

    if ( true === $args['autofocus'] ) {
      $args['custom_attributes']['autofocus'] = 'autofocus';
    }

    if ( $args['description'] ) {
      $args['custom_attributes']['aria-describedby'] = $args['id'] . '-description';
    }

    if ( ! empty( $args['custom_attributes'] ) && is_array( $args['custom_attributes'] ) ) {
      foreach ( $args['custom_attributes'] as $attribute => $attribute_value ) {
        $custom_attributes[] = esc_attr( $attribute ) . '="' . esc_attr( $attribute_value ) . '"';
      }
    }

    if ( ! empty( $args['validate'] ) ) {
      foreach ( $args['validate'] as $validate ) {
        $args['class'][] = 'validate-' . $validate;
      }
    }

    $field           = '';
    $label_id        = $args['id'];
    $sort            = $args['priority'] ? $args['priority'] : '';
    $field_container = '<div class="col-md-6 %1$s" id="%2$s" data-priority="' . esc_attr( $sort ) . '"><div class="form-group">%3$s</div></div>';

    switch ( $args['type'] ) {
      case 'country':
        $countries = 'shipping_country' === $key ? WC()->countries->get_shipping_countries() : WC()->countries->get_allowed_countries();

        if ( 1 === count( $countries ) ) {

          $field .= '<strong>' . current( array_values( $countries ) ) . '</strong>';

          $field .= '<input type="hidden" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="' . current( array_keys( $countries ) ) . '" ' . implode( ' ', $custom_attributes ) . ' class="country_to_state" readonly="readonly" />';

        } else {

          $field = '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="form-control country_to_state country_select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . '><option value="default">' . esc_html__( 'Select a country / region&hellip;', 'woocommerce' ) . '</option>';

          foreach ( $countries as $ckey => $cvalue ) {
            $field .= '<option value="' . esc_attr( $ckey ) . '" ' . selected( $value, $ckey, false ) . '>' . esc_html( $cvalue ) . '</option>';
          }

          $field .= '</select>';

          $field .= '<noscript><button type="submit" name="woocommerce_checkout_update_totals" value="' . esc_attr__( 'Update country / region', 'woocommerce' ) . '">' . esc_html__( 'Update country / region', 'woocommerce' ) . '</button></noscript>';

        }

        break;
      case 'state':
        /* Get country this state field is representing */
        $for_country = isset( $args['country'] ) ? $args['country'] : WC()->checkout->get_value( 'billing_state' === $key ? 'billing_country' : 'shipping_country' );
        $states      = WC()->countries->get_states( $for_country );

        if ( is_array( $states ) && empty( $states ) ) {

          $field_container = '<div class="col-md-6 %1$s" id="%2$s" style="display: none"><div class="form-group">%3$s</div></div>';

          $field .= '<input type="hidden" class="hidden" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="" ' . implode( ' ', $custom_attributes ) . ' placeholder="' . esc_attr( $args['placeholder'] ) . '" readonly="readonly" data-input-classes="' . esc_attr( implode( ' ', $args['input_class'] ) ) . '"/>';

        } elseif ( ! is_null( $for_country ) && is_array( $states ) ) {

          $field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="state_select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ? $args['placeholder'] : esc_html__( 'Select an option&hellip;', 'woocommerce' ) ) . '"  data-input-classes="' . esc_attr( implode( ' ', $args['input_class'] ) ) . '">
            <option value="">' . esc_html__( 'Select an option&hellip;', 'woocommerce' ) . '</option>';

          foreach ( $states as $ckey => $cvalue ) {
            $field .= '<option value="' . esc_attr( $ckey ) . '" ' . selected( $value, $ckey, false ) . '>' . esc_html( $cvalue ) . '</option>';
          }

          $field .= '</select>';

        } else {

          $field .= '<input type="text" class="form-control' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" value="' . esc_attr( $value ) . '"  placeholder="' . esc_attr( $args['placeholder'] ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" ' . implode( ' ', $custom_attributes ) . ' data-input-classes="' . esc_attr( implode( ' ', $args['input_class'] ) ) . '"/>';

        }

        break;
      case 'textarea':
        $field .= '<textarea name="' . esc_attr( $key ) . '" class="form-control' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . ( empty( $args['custom_attributes']['rows'] ) ? ' rows="2"' : '' ) . ( empty( $args['custom_attributes']['cols'] ) ? ' cols="5"' : '' ) . implode( ' ', $custom_attributes ) . '>' . esc_textarea( $value ) . '</textarea>';

        break;
      case 'checkbox':
        $field = '<label class="checkbox ' . implode( ' ', $args['label_class'] ) . '" ' . implode( ' ', $custom_attributes ) . '>
            <input type="' . esc_attr( $args['type'] ) . '" class="input-checkbox ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="1" ' . checked( $value, 1, false ) . ' /> ' . $args['label'] . $required . '</label>';

        break;
      case 'text':
      case 'password':
      case 'datetime':
      case 'datetime-local':
      case 'date':
      case 'month':
      case 'time':
      case 'week':
      case 'number':
      case 'email':
      case 'url':
      case 'tel':
        $field .= '<input type="' . esc_attr( $args['type'] ) . '" class="form-control' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '"  value="' . esc_attr( $value ) . '" ' . implode( ' ', $custom_attributes ) . ' />';

        break;
      case 'hidden':
        $field .= '<input type="' . esc_attr( $args['type'] ) . '" class="input-hidden ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="' . esc_attr( $value ) . '" ' . implode( ' ', $custom_attributes ) . ' />';

        break;
      case 'select':
        $field   = '';
        $options = '';

        if ( ! empty( $args['options'] ) ) {
          foreach ( $args['options'] as $option_key => $option_text ) {
            if ( '' === $option_key ) {
              // If we have a blank option, select2 needs a placeholder.
              if ( empty( $args['placeholder'] ) ) {
                $args['placeholder'] = $option_text ? $option_text : __( 'Choose an option', 'woocommerce' );
              }
              $custom_attributes[] = 'data-allow_clear="true"';
            }
            $options .= '<option value="' . esc_attr( $option_key ) . '" ' . selected( $value, $option_key, false ) . '>' . esc_html( $option_text ) . '</option>';
          }

          $field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ) . '">
              ' . $options . '
            </select>';
        }

        break;
      case 'radio':
        $label_id .= '_' . current( array_keys( $args['options'] ) );

        if ( ! empty( $args['options'] ) ) {
          foreach ( $args['options'] as $option_key => $option_text ) {
            $field .= '<input type="radio" class="input-radio ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" value="' . esc_attr( $option_key ) . '" name="' . esc_attr( $key ) . '" ' . implode( ' ', $custom_attributes ) . ' id="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '"' . checked( $value, $option_key, false ) . ' />';
            $field .= '<label for="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '" class="radio ' . implode( ' ', $args['label_class'] ) . '">' . esc_html( $option_text ) . '</label>';
          }
        }

        break;
    }

    if ( ! empty( $field ) ) {
      $field_html = '';

      if ( $args['label'] && 'checkbox' !== $args['type'] ) {
        $field_html .= '<label for="' . esc_attr( $label_id ) . '" class="' . esc_attr( implode( ' ', $args['label_class'] ) ) . '">' . wp_kses_post( $args['label'] ) . $required . '</label>';
      }

      $field_html .= '' . $field;

      if ( $args['description'] ) {
        $field_html .= '<span class="description" id="' . esc_attr( $args['id'] ) . '-description" aria-hidden="true">' . wp_kses_post( $args['description'] ) . '</span>';
      }

      $field_html .= '';

      $container_class = esc_attr( implode( ' ', $args['class'] ) );
      $container_id    = esc_attr( $args['id'] ) . '_field';
      $field           = sprintf( $field_container, $container_class, $container_id, $field_html );
    }

    /**
     * Filter by type.
     */
    $field = apply_filters( 'woocommerce_form_field_' . $args['type'], $field, $key, $args, $value );

    /**
     * General filter on form fields.
     *
     * @since 3.4.0
     */
    $field = apply_filters( 'woocommerce_form_field', $field, $key, $args, $value );

    if ( $args['return'] ) {
      return $field;
    } else {
      // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
      echo $field;
    }
  }
}











<div class="col-lg-7 col-md-12">
       
  <?php if ( $checkout->get_checkout_fields() ) : ?>


  <div class="checkout-form box-shadow white-bg">
          <h4 class="mb-4 font-w-6">Billing Details</h4>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>First Name</label>
                <input type="text" id="fname" class="form-control" placeholder="Your firstname">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Last Name</label>
                <input type="text" id="lname" class="form-control" placeholder="Your lastname">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>E-mail Address</label>
                <input type="text" id="email" class="form-control" placeholder="State Province">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Phone Number</label>
                <input type="text" id="phone" class="form-control" placeholder="">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Company Name</label>
                <input type="text" id="companyname" class="form-control" placeholder="Company Name">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Select Country</label>
                <select name="people" id="people" class="form-control">
                    <option value="#">Select country</option>
                    <option value="#">Alaska</option>
                    <option value="#">China</option>
                    <option value="#">Japan</option>
                    <option value="#">Korea</option>
                    <option value="#">Philippines</option>
                  </select>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Address</label>
                <input type="text" id="address" class="form-control" placeholder="Enter Your Address">
              </div>
              <div class="form-group">
                <input type="text" id="address2" class="form-control" placeholder="Second Address">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Town/City</label>
                <input type="text" id="towncity" class="form-control" placeholder="Town or City">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mb-md-0">
                <label>State/Province</label>
                <input type="text" id="statename" class="form-control" placeholder="State Province">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mb-md-0">
                <label>Zip/Postal Code</label>
                <input type="text" id="zippostalcode" class="form-control" placeholder="Zip / Postal">
              </div>
            </div>
        </div>
    </div>   
  <?php endif; ?>
   </div>



 Checkout Left Sidebar:
 .......................
 .......................
<div>
<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>


<?php do_action( 'woocommerce_checkout_after_order_review' );?>
</div>


Coupon:::
  <form class="checkout_coupon woocommerce-form-coupon" method="post">
        <div class="mb-7">
              <label class="text-black mb-3">

             </label>
              <div class="input-group">

                <input type="text" name="coupon_code" class="form-control" placeholder="<?php esc_attr_e( 'Coupon Code', 'woocommerce' ); ?>" id="coupon_code" value="" />
               
                <div class="input-group-append">
                  <button type="submit" class="btn btn-primary btn-sm px-4" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_html_e( 'Apply coupon', 'woocommerce' ); ?></button>
                </div>

              </div>
            </div>
        </form>

 Full PAGE

 .............

<?php
/**
 * Checkout Form
 
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
  echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
  return;
}

?>





<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">











    <div class="row">


  <div class="col-lg-7 col-md-12">
       
  <?php if ( $checkout->get_checkout_fields() ) : ?>
    

  <div class="checkout-form box-shadow white-bg">
          <h4 class="mb-4 font-w-6">Billing Details</h4>
           <div class="row">
            <?php
    $fields = $checkout->get_checkout_fields( 'billing' );

    foreach ( $fields as $key => $field ) {
      woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
    }
    ?>
  



            
            <div class="col-md-6 sazzad">
              <div class="form-group">
                <label>First Name</label>
                <input type="text" id="billing_first_name" name="billing_first_name" class="form-control" placeholder="Your firstname">
              </div>
            </div>



            
            <div class="col-md-6">
              <div class="form-group">
                <label>Last Name</label>
                <input type="text" id="billing_last_name" name="billing_last_name" class="form-control" placeholder="Your lastname">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>E-mail Address</label>
                <input type="text" id="billing_email" name="billing_email" class="form-control" placeholder="State Province">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Phone Number</label>
                <input type="number" id="billing_phone" name="billing_phone" class="form-control" placeholder="">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Company Name</label>
                <input type="text" id="billing_company" name="billing_company" class="form-control" placeholder="Company Name">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Select Country</label>

                <select name="billing_country" id="billing_country" class="form-control select2">
                    <option value="#">Select country</option>
                    <option value="#">Alaska</option>
                    <option value="#">China</option>
                    <option value="#">Japan</option>
                    <option value="#">Korea</option>
                    <option value="#">Philippines</option>
                  </select>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Address</label>
                <input type="text" id="billing_address_1" name="billing_address_1" class="form-control" placeholder="Enter Your Address">
              </div>
              <div class="form-group">
                <input type="text" id="billing_address_2" name="billing_address_2" class="form-control" placeholder="Second Address">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Town/City</label>
                <input type="text" id="billing_city" name="billing_city" class="form-control" placeholder="Town or City">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mb-md-0">
                <label>State/Province</label>

                <input type="text" id="billing_state" name="billing_state" class="form-control" placeholder="State Province">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mb-md-0">
                <label>Zip/Postal Code</label>
                <input type="text" id="billing_postcode" name="billing_postcode" class="form-control" placeholder="Zip / Postal">
              </div>
            </div>



















          </div>
    </div>  
   
  <?php endif; ?>

   
   </div>


</form>

  








  <div class="col-lg-5 col-md-12 mt-5 mt-lg-0">
    <div class="border bg-light-4 p-3 p-lg-5">

        <div class="mb-7">
          <?php echo bbloomer_display_coupon_form_below_proceed_checkout();?>
  
        </div>


  
<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

  <div id="order_review" class="woocommerce-checkout-review-order">
    <?php do_action( 'woocommerce_checkout_order_review' ); ?>
  </div>

<?php do_action( 'woocommerce_checkout_after_order_review' );?>

  </div>
</div>

  </div>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

</div>




Review-porder::

<?php
/**
 * Review order table
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/review-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.8.0
 */

defined( 'ABSPATH' ) || exit;
?>



  <div class="mb-7">
          <h6 class="mb-3 font-w-6">Your Order</h6>
        

          <ul class="list-unstyled">

       <?php
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
      $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );

      if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
        ?>
            <li class="mb-3 border-bottom pb-3 d-flex"><span class="mr-auto"> 

              <?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;';?>


            <?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <span>' . sprintf( '&times;&nbsp;%s', $cart_item['quantity'] ) . '</span>', $cart_item, $cart_item_key ); ?>
            <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?> 
          </span> 



      <span><?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );  ?>.00</span>
    </li>
    <?php
      }
    }
    ?>

     <li class="mb-3 border-bottom pb-3 d-flex"><span class="mr-auto"> Subtotal </span> <span><?php wc_cart_totals_subtotal_html(); ?>.00</span></li>

    <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
      <li class="mb-3 border-bottom pb-3 d-flex coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
        <th><?php wc_cart_totals_coupon_label( $coupon ); ?></th>
        <td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
      </li>
    <?php endforeach; ?>
    
            <li class="mb-3 border-bottom pb-3 d-flex"><span class="mr-auto"> Shipping </span> <span>$99.00</span></li>
           
            <li class="d-flex"><span class="mr-auto"><strong class="cart-total"> Total :</strong></span>  <strong class="cart-total"><?php wc_cart_totals_order_total_html(); ?>.00 </strong>
            </li>
          </ul>
    

        </div>


Payment method::


<?php
/**
 * Output a single payment method
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/payment-method.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}
?>
<div class="form-group payment_method_<?php echo esc_attr( $gateway->id ); ?>">
<div class="custom-control custom-radio">
  <input id="payment_method_<?php echo esc_attr( $gateway->id ); ?>" type="radio" class="input-radio custom-control-input" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?> data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>" />

  <label class="custom-control-label" for="payment_method_<?php echo esc_attr( $gateway->id ); ?>">
    <?php echo $gateway->get_title(); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?> <?php echo $gateway->get_icon(); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?>
  </label>
    
  
</div>
</div>










My Account page:
====================================================================================================================================================================================

Dashboard::
<?php echo esc_html( $current_user->display_name )?>!
       <p><?php
  /* translators: 1: Orders URL 2: Address URL 3: Account URL. */
  $dashboard_desc = __( 'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.', 'woocommerce' );
  if ( wc_shipping_enabled() ) {
    /* translators: 1: Orders URL 2: Addresses URL 3: Account URL. */
    $dashboard_desc = __( 'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.', 'woocommerce' );
  }
  printf(
    wp_kses( $dashboard_desc, $allowed_html ),
    esc_url( wc_get_endpoint_url( 'orders' ) ),
    esc_url( wc_get_endpoint_url( 'edit-address' ) ),
    esc_url( wc_get_endpoint_url( 'edit-account' ) )
  );
  ?></p>




  My Orders:::

 <?php
  $customer_orders = get_posts(
  apply_filters(
    'woocommerce_my_account_my_orders_query',
    array(
      'numberposts' => $order_count,
      'meta_key'    => '_customer_user',
      'meta_value'  => get_current_user_id(),
      'post_type'   => wc_get_order_types( 'view-orders' ),
      'post_status' => array_keys( wc_get_order_statuses() ),
    )
  )
);


      foreach ( $customer_orders as $customer_order ) :
        $order      = wc_get_order( $customer_order ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
        $item_count = $order->get_item_count();
        ?>
         <tr>
    <?php 


$my_orders_columns = apply_filters(
  'woocommerce_my_account_my_orders_columns',
  array(
    'order-number'  => esc_html__( 'Order', 'woocommerce' ),
    'order-date'    => esc_html__( 'Date', 'woocommerce' ),
    'order-status'  => esc_html__( 'Status', 'woocommerce' ),
    'order-total'   => esc_html__( 'Total', 'woocommerce' ),
    'order-actions' => '&nbsp;',
  )
);




                                              foreach ( $my_orders_columns as $column_id => $column_name ) : ?>
            <td class="<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">
              <?php if ( has_action( 'woocommerce_my_account_my_orders_column_' . $column_id ) ) : ?>
                <?php do_action( 'woocommerce_my_account_my_orders_column_' . $column_id, $order ); ?>

              <?php elseif ( 'order-number' === $column_id ) : ?>
                <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>">
                  <?php echo _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </a>

              <?php elseif ( 'order-date' === $column_id ) : ?>
                <time datetime="<?php echo esc_attr( $order->get_date_created()->date( 'c' ) ); ?>"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></time>

              <?php elseif ( 'order-status' === $column_id ) : ?>
                <?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>

              <?php elseif ( 'order-total' === $column_id ) : ?>
                <?php
                /* translators: 1: formatted order total 2: total order items */
                printf( _n( '%1$s for %2$s item', '%1$s for %2$s items', $item_count, 'woocommerce' ), $order->get_formatted_order_total(), $item_count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                ?>

              <?php elseif ( 'order-actions' === $column_id ) : ?>
                <?php
                $actions = wc_get_account_orders_actions( $order );

                if ( ! empty( $actions ) ) {
                  foreach ( $actions as $key => $action ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
                    echo '<a href="' . esc_url( $action['url'] ) . '" class="button ' . sanitize_html_class( $key ) . '">' . esc_html( $action['name'] ) . '</a>';
                  }
                }
                ?>
              <?php endif; ?>
            </td>
          <?php endforeach; ?>



                                               
  </tr>
 <?php endforeach; ?>



ACOUNT DETAILS:
=============




<li class="nav-item">
  <a class="nav-link" href="<?php echo esc_url( wc_logout_url() )?>">Logout</a>
</li>



                      Login Page
==========================================================================================================================
  
  URL
   <?php if ( is_user_logged_in() ) { ?>
  <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','woothemes'); ?>"><?php _e('My Account','woothemes'); ?></a>
 <?php } 
 else { ?>
  <a class="mr-1 mr-sm-3" href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Login / Register','woothemes'); ?>"><?php _e('<i class="las la-user-alt"></i>','woothemes'); ?></a>
 <?php } ?>  






      <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="username"><?php esc_html_e( 'Username or email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
        <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
      </p>


      <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
        <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" />
      </p>

      <?php do_action( 'woocommerce_login_form' ); ?>

      <p class="form-row">
        <label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
          <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Remember me', 'woocommerce' ); ?></span>
        </label>
        <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
        <button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce' ); ?></button>
      </p>
      <p class="woocommerce-LostPassword lost_password">
        <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'woocommerce' ); ?></a>
      </p>


<div class="form-group mt-4 mb-5">
              <div class="remember-checkbox d-flex align-items-center justify-content-between">
                <div class="checkbox">
                  <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                  <label for="check2">Remember me</label>
                </div>
                 <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Forgot Password?</a>
              </div>
            </div> 
              <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
        <button type="submit" class="btn btn-primary btn-block" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce' ); ?></button>







example:::


  <div class="page-content">

<!--login start-->

<section class="bg-light">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-6 col-md-8 col-sm-11">
        <div class="shadow p-6 login bg-white">
         <div class="store-name">flipmarto</div>



<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

<div class="" id="">
  

  <?php endif; ?>

  <h4 class="text-left mb-3 font-w-5">Customer Login</h4>


    <form class="" method="post">

      <?php do_action( 'woocommerce_login_form_start' ); ?>



       
              

      <div class="form-group">
        <input type="text" class="form-control" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" />
        <div class="help-block with-errors"></div>
      </div>




      <div class="form-group">
        <input class="form-control" type="password" name="password" id="password" autocomplete="current-password" />
      </div>




      <?php do_action( 'woocommerce_login_form' ); ?>


       <div class="form-group mt-4 mb-5">
              <div class="remember-checkbox d-flex align-items-center justify-content-between">
                <div class="checkbox">
                  <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                  <label for="check2">Remember me</label>
                </div>
                 <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Forgot Password?</a>
              </div>
            </div> 
              <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
        <button type="submit" class="btn btn-primary btn-block" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce' ); ?></button>


      

      <?php do_action( 'woocommerce_login_form_end' ); ?>

    </form>

<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>



 <?php              
Checkout field rename:::
==========================
===========================
===========================


add_filter( 'woocommerce_checkout_fields', 'bbloomer_rename_woo_checkout_fields' );
  
function bbloomer_rename_woo_checkout_fields( $fields ) {
    $fields['billing']['billing_first_name']['placeholder'] = 'Your First Name';
    $fields['billing']['billing_first_name']['label'] = 'First Name';
    return $fields;
}



?>


   Woocommerce Single  Page:
 ================================================================================================================================================================================================

 Custom Quantity:::
===================

loop/input-quqntity::


<div class="quantity">
    <label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></label>
    <input type="button" value="-" class="qty_button minus" />
    <input
        type="number"
        id="<?php echo esc_attr( $input_id ); ?>"
        class="form-control qty text"
        step="<?php echo esc_attr( $step ); ?>"
        min="<?php echo esc_attr( $min_value ); ?>"
        max="<?php echo esc_attr( 0 < $max_value ? $max_value : '' ); ?>"
        name="<?php echo esc_attr( $input_name ); ?>"
        value="<?php echo esc_attr( $input_value ); ?>"
        title="<?php echo esc_attr_x( 'Qty', 'Product quantity input tooltip', 'woocommerce' ); ?>"
        size="4"
        pattern="<?php echo esc_attr( $pattern ); ?>"
        inputmode="<?php echo esc_attr( $inputmode ); ?>"
        aria-labelledby="<?php echo esc_attr( $labelledby ); ?>" />
    <input type="button" value="+" class="qty_button plus" />
</div>
<?php


// Minimum CSS to remove +/- default buttons on input field type number
add_action( 'wp_head' , 'custom_quantity_fields_css' );
function custom_quantity_fields_css(){
    ?>
    <style>
    .quantity input::-webkit-outer-spin-button,
    .quantity input::-webkit-inner-spin-button {
        display: none;
        margin: 0;
    }
    .quantity input.qty {
        appearance: textfield;
        -webkit-appearance: none;
        -moz-appearance: textfield;
    }
    </style>
    <?php
}


add_action( 'wp_footer' , 'custom_quantity_fields_script' );
function custom_quantity_fields_script(){
    ?>
    <script type='text/javascript'>
    jQuery( function( $ ) {
        if ( ! String.prototype.getDecimals ) {
            String.prototype.getDecimals = function() {
                var num = this,
                    match = ('' + num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
                if ( ! match ) {
                    return 0;
                }
                return Math.max( 0, ( match[1] ? match[1].length : 0 ) - ( match[2] ? +match[2] : 0 ) );
            }
        }
        // Quantity "plus" and "minus" buttons
        $( document.body ).on( 'click', '.plus, .minus', function() {
            var $qty        = $( this ).closest( '.quantity' ).find( '.qty'),
                currentVal  = parseFloat( $qty.val() ),
                max         = parseFloat( $qty.attr( 'max' ) ),
                min         = parseFloat( $qty.attr( 'min' ) ),
                step        = $qty.attr( 'step' );

            // Format values
            if ( ! currentVal || currentVal === '' || currentVal === 'NaN' ) currentVal = 0;
            if ( max === '' || max === 'NaN' ) max = '';
            if ( min === '' || min === 'NaN' ) min = 0;
            if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) step = 1;

            // Change the value
            if ( $( this ).is( '.plus' ) ) {
                if ( max && ( currentVal >= max ) ) {
                    $qty.val( max );
                } else {
                    $qty.val( ( currentVal + parseFloat( step )).toFixed( step.getDecimals() ) );
                }
            } else {
                if ( min && ( currentVal <= min ) ) {
                    $qty.val( min );
                } else if ( currentVal > 0 ) {
                    $qty.val( ( currentVal - parseFloat( step )).toFixed( step.getDecimals() ) );
                }
            }

            // Trigger change event
            $qty.trigger( 'change' );
        });
    });
    </script>
    <?php
}



 Variable product :
 ==================


 function bbloomer_variation_price_format_min( $price, $product ) {
   $prices = $product->get_variation_prices( true );
   $min_price = current( $prices['price'] );
   $price = sprintf( __( 'From: %1$s', 'woocommerce' ), wc_price( $min_price ) );
   return $price;
}

add_filter( 'woocommerce_variable_price_html', 'bbloomer_variation_price_format_min', 9999, 2 );




 Custom offer::
 ================
 ================
 =================


function bbloomer_show_sale_percentage_loop() {
   global $product;
   if ( ! $product->is_on_sale() ) return;
   if ( $product->is_type( 'simple' ) ) {
      $max_percentage = ( ( $product->get_regular_price() - $product->get_sale_price() ) / $product->get_regular_price() ) * 100;
   } elseif ( $product->is_type( 'variable' ) ) {
      $max_percentage = 0;
      foreach ( $product->get_children() as $child_id ) {
         $variation = wc_get_product( $child_id );
         $price = $variation->get_regular_price();
         $sale = $variation->get_sale_price();
         if ( $price != 0 && ! empty( $sale ) ) $percentage = ( $price - $sale ) / $price * 100;
         if ( $percentage > $max_percentage ) {
            $max_percentage = $percentage;
         }
      }
   }
   if ( $max_percentage > 0 ) echo "<div class='sale-label'>-" . round($max_percentage) . "%</div>"; 
}

add_action( 'woocommerce_before_shop_loop_item_title', 'bbloomer_show_sale_percentage_loop', 25 );


 
add_action( 'wp_footer', 'bbloomer_add_cart_quantity_plus_minus' );
  
function bbloomer_add_cart_quantity_plus_minus() {
   // Only run this on the single product page
   if ( ! is_product() ) return;
   ?>
      <script type="text/javascript">
           
      jQuery(document).ready(function($){   
           
         $('form.cart').on( 'click', 'button.plus, button.minus', function() {
  
            // Get current quantity values
            var qty = $( this ).closest( 'form.cart' ).find( '.qty' );
            var val   = parseFloat(qty.val());
            var max = parseFloat(qty.attr( 'max' ));
            var min = parseFloat(qty.attr( 'min' ));
            var step = parseFloat(qty.attr( 'step' ));
  
            // Change the value if plus or minus
            if ( $( this ).is( '.plus' ) ) {
               if ( max && ( max <= val ) ) {
                  qty.val( max );
               } else {
                  qty.val( val + step );
               }
            } else {
               if ( min && ( min >= val ) ) {
                  qty.val( min );
               } else if ( val > 1 ) {
                  qty.val( val - step );
               }
            }
              
         });
           
      });
           
      </script>
   <?php
}










image:
=====

<?php

if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
  return;
}

global $product;

$attachment_ids = $product->get_gallery_image_ids();

if ( $attachment_ids && $product->get_image_id() ) {
  
  foreach ( $attachment_ids as $attachment_id ) {
    echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', wc_get_gallery_image_html( $attachment_id ), $attachment_id ); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped
  }
}?>            



single image css:


ol.flex-control-nav.flex-control-thumbs {
    display: flex;
    margin-top: 20px;
}

ol.flex-control-nav.flex-control-thumbs li{
    list-style:none;
}

ol.flex-control-nav.flex-control-thumbs {
    margin-left: -40px;
}








Add to Cart:
===========

 <form class="cart" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data'>

    <?php
   
    woocommerce_quantity_input(
      array(
        'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
        'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
        'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
      )
    );

  
    ?>
  </form>





Related Product:
================

 <?php echo woocommerce_output_related_products();?>

 Output the related products.line no:1927

$args = array(
      'posts_per_page' => -1,
      'columns'        => 1,
      'orderby'        => 'rand', // @codingStandardsIgnoreLine.
    );

related.php

    <?php

if ( $related_products ) : ?>

  <div class="related products ">
    
    
      
    <?php woocommerce_product_loop_start(); ?>
    
        <div class="owl-carousel no-pb owl-2" data-dots="false" data-nav="true" data-items="4" data-md-items="2" data-sm-items="1">

      <?php foreach ( $related_products as $related_product ) : ?>

          <?php
          $post_object = get_post( $related_product->get_id() );

          setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

          wc_get_template_part( 'content', 'product' );
          ?>

      <?php endforeach; ?>
         
    </div>


    <?php woocommerce_product_loop_end(); ?>

  </div>
  <?php
endif;

wp_reset_postdata();
?>


Tab content:
===========

Color Attribute:
----------------
<?php do_action( 'woocommerce_product_additional_information', $product ); ?>

<table class="table table-bordered mb-0">
  <?php foreach ( $product_attributes as $product_attribute_key => $product_attribute ) : ?>
    <tr class="<?php echo esc_attr( $product_attribute_key ); ?>">
      <td><?php echo wp_kses_post( $product_attribute['label'] ); ?></td>
      <td><?php echo wp_kses_post( $product_attribute['value'] ); ?></td>
    </tr>
  <?php endforeach; ?>
</table>



Review:
------
<?php echo woocommerce_output_product_data_tabs();?>
 
function.php
=============
add_filter( 'woocommerce_product_tabs', 'bbloomer_remove_product_tabs', 9999 );
  
function bbloomer_remove_product_tabs( $tabs ) {
    unset( $tabs['description'] ); 
    unset( $tabs['additional_information'] ); 
    return $tabs;
}





















Register Page::
<?php
  /*
   * Template name: Register
   */
?>
<?php if(is_user_logged_in()){
  wp_redirect(get_permalink(get_option('woocommerce_myaccount_page_id')));
} ?>
<?php get_header();?>
<?php do_action( 'woocommerce_before_customer_login_form' ); ?>


<section id="register_page" class="register_page">
  <div class="container">
    <div class="register_structure">
      <form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >
        <?php do_action( 'woocommerce_register_form_start' ); ?>
        <div class="form-box">
          <div class="section-title custom-title">
            <h2><?php esc_html_e( 'Register', 'woocommerce' ); ?></h2>
          </div>
          <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
            <div class="item">
              <label for="reg_username"><?php esc_html_e( 'Nume si prenume*', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
              <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
            </div>
          <?php endif; ?>
          <div class="item">
            <label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
            <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
          </div>

             <p class="form-row form-row-last">
       <label for="reg_billing_last_name"><?php _e( 'Last name', 'woocommerce' ); ?><span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_last_name" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['billing_last_name'] ) ) esc_attr_e( $_POST['billing_last_name'] ); ?>" />
       </p>
          <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
            <div class="item">
              <label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
              <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
            </div>
          <?php else : ?>
            <p><?php esc_html_e( 'A password will be sent to your email address.', 'woocommerce' ); ?></p>
          <?php endif; ?>
          
        </div>


   <p class="form-row form-row-wide">
       <label for="reg_billing_phone"><?php _e( 'Phone', 'woocommerce' ); ?></label>
       <input type="text" class="input-text" name="billing_phone" id="reg_billing_phone" value="<?php esc_attr_e( $_POST['billing_phone'] ); ?>" />
       </p>
       <p class="form-row form-row-first">
       <label for="reg_billing_first_name"><?php _e( 'First name', 'woocommerce' ); ?><span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_first_name" id="reg_billing_first_name" value="<?php if ( ! empty( $_POST['billing_first_name'] ) ) esc_attr_e( $_POST['billing_first_name'] ); ?>" />
       </p>
       <p class="form-row form-row-last">
       <label for="reg_billing_last_name"><?php _e( 'Last name', 'woocommerce' ); ?><span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_last_name" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['billing_last_name'] ) ) esc_attr_e( $_POST['billing_last_name'] ); ?>" />
       </p>






        <?php do_action( 'woocommerce_register_form' ); ?>
        <div class="item btn-default">
          <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
          <button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
        </div>
        <?php do_action( 'woocommerce_register_form_end' ); ?>
      </form>
    </div>
  </div>
</section>
<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
<?php get_footer();?>















                      Homepage:
========================================================================================================================

Flash Deals:
...........

 <!-- WooCommerce On-Sale Products -->
       <?php
            $args = array(
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'meta_query'     => array(
                    'relation' => 'OR',
                    array( // Simple products type
                        'key'           => '_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    ),
                    array( // Variable products type
                        'key'           => '_min_variation_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    )
                )
        );
        $loop = new WP_Query( $args );
        if ( $loop->have_posts() ) {
            while ( $loop->have_posts() ) : $loop->the_post();
              ?>


...............code Here...............................

    <?php
            endwhile;
        } else {
            echo __( 'No products found' );
        }
        wp_reset_postdata();
    ?>



<?php
//Offers 
function bbloomer_show_sale_percentage_loop() {
   global $product;
   if ( ! $product->is_on_sale() ) return;
   if ( $product->is_type( 'simple' ) ) {
      $max_percentage = ( ( $product->get_regular_price() - $product->get_sale_price() ) / $product->get_regular_price() ) * 100;
   } elseif ( $product->is_type( 'variable' ) ) {
      $max_percentage = 0;
      foreach ( $product->get_children() as $child_id ) {
         $variation = wc_get_product( $child_id );
         $price = $variation->get_regular_price();
         $sale = $variation->get_sale_price();
         if ( $price != 0 && ! empty( $sale ) ) $percentage = ( $price - $sale ) / $price * 100;
         if ( $percentage > $max_percentage ) {
            $max_percentage = $percentage;
         }
      }
   }
   if ( $max_percentage > 0 ) echo "<div class='sale-label'>-" . round($max_percentage) . "% off</div>"; 
}

add_action( 'woocommerce_before_shop_loop_item_title', 'bbloomer_show_sale_percentage_loop');


Example:
.......
  <div class="owl-carousel no-pb owl-2" data-dots="false" data-nav="true" data-items="4" data-md-items="2" data-sm-items="1">

 
    <!-- WooCommerce On-Sale Products -->
       <?php
            $args = array(
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'meta_query'     => array(
                    'relation' => 'OR',
                    array( // Simple products type
                        'key'           => '_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    ),
                    array( // Variable products type
                        'key'           => '_min_variation_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    )
                )
        );
        $loop = new WP_Query( $args );
        if ( $loop->have_posts() ) {
            while ( $loop->have_posts() ) : $loop->the_post();
              ?>

        
                      <div class="card product-card card--default rounded-0">
                   <?php echo bbloomer_show_sale_percentage_loop();?>
                     <?php echo woocommerce_template_loop_product_thumbnail()?>

                        <div class="card-icons">
                          <div class="card-icons__item"> <a href="#" data-toggle="tooltip" data-placement="left" title="" data-original-title="Add to wishlist"> <i class="lar la-heart"></i> </a> </div>
                          <div class="card-icons__item"> <a href="#" data-toggle="tooltip" data-placement="left" title="" data-original-title="Quick View"><span data-target="#quick-view" data-toggle="modal"> <i class="ion-ios-search-strong"></i></span> </a> </div>
                          <div class="card-icons__item"> <a href="#" data-toggle="tooltip" data-placement="left" title="" data-original-title="Compare"> <i class="las la-random"></i> </a> </div>
                        </div>
                        <div class="card-info">
                          <div class="card-body">
                          <div class="product_color_switch">
                          <span class="active" data-color="#3e3e40" style="background-color:#3e3e40" data-toggle="tooltip" data-placement="top" title="" data-original-title="Black"></span>
                           <span data-color="#ac4e10" style="background-color:#ac4e10" data-toggle="tooltip" data-placement="top" title="" data-original-title="Brown"></span>
                            <span data-color="#e8e7e5" style="background-color:#e8e7e5" data-toggle="tooltip" data-placement="top" title="" data-original-title="Grey"></span>
                                            </div>
                            <div class="product-title font-w-5"><a class="link-title" href="product-left-image.html">Unpaired Running Shoes</a> </div>
                            <div class="mt-1"> <span class="product-price text-pink"><del class="text-muted">$35.00</del> $25.00</span>
                              <div class="star-rating"><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i> </div>
                            </div>
                          </div>
                          <div class="card-footer bg-transparent border-0">
                            <div class="product-link d-flex align-items-center justify-content-center">
                              <button class="btn-cart btn btn-pink mx-3" type="button"><i class="las la-shopping-cart mr-1"></i> Add to cart </button>
                            </div>
                          </div>
                        </div>
                      </div>
                   

              <?php
            endwhile;
        } else {
            echo __( 'No products found' );
        }
        wp_reset_postdata();
    ?>



<form class="woocommerce-EditAccountForm edit-account" action="" method="post" <?php do_action( 'woocommerce_edit_account_form_tag' ); ?> >

  <?php do_action( 'woocommerce_edit_account_form_start' ); ?>

  <p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
    <label for="account_first_name"><?php esc_html_e( 'First name', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_first_name" id="account_first_name" autocomplete="given-name" value="<?php echo esc_attr( $user->first_name ); ?>" />
  </p>
  <p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
    <label for="account_last_name"><?php esc_html_e( 'Last name', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_last_name" id="account_last_name" autocomplete="family-name" value="<?php echo esc_attr( $user->last_name ); ?>" />
  </p>
  <div class="clear"></div>

  <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
    <label for="account_display_name"><?php esc_html_e( 'Display name', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_display_name" id="account_display_name" value="<?php echo esc_attr( $user->display_name ); ?>" /> <span><em><?php esc_html_e( 'This will be how your name will be displayed in the account section and in reviews', 'woocommerce' ); ?></em></span>
  </p>
  <div class="clear"></div>

  <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
    <label for="account_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
    <input type="email" class="woocommerce-Input woocommerce-Input--email input-text" name="account_email" id="account_email" autocomplete="email" value="<?php echo esc_attr( $user->user_email ); ?>" />
  </p>

  <fieldset>
    <legend><?php esc_html_e( 'Password change', 'woocommerce' ); ?></legend>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
      <label for="password_current"><?php esc_html_e( 'Current password (leave blank to leave unchanged)', 'woocommerce' ); ?></label>
      <input type="password" class="woocommerce-Input woocommerce-Input--password input-text" name="password_current" id="password_current" autocomplete="off" />
    </p>
    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
      <label for="password_1"><?php esc_html_e( 'New password (leave blank to leave unchanged)', 'woocommerce' ); ?></label>
      <input type="password" class="woocommerce-Input woocommerce-Input--password input-text" name="password_1" id="password_1" autocomplete="off" />
    </p>
    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
      <label for="password_2"><?php esc_html_e( 'Confirm new password', 'woocommerce' ); ?></label>
      <input type="password" class="woocommerce-Input woocommerce-Input--password input-text" name="password_2" id="password_2" autocomplete="off" />
    </p>
  </fieldset>
  <div class="clear"></div>

  <?php do_action( 'woocommerce_edit_account_form' ); ?>

  <p>
    <?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>
    <button type="submit" class="woocommerce-Button button" name="save_account_details" value="<?php esc_attr_e( 'Save changes', 'woocommerce' ); ?>"><?php esc_html_e( 'Save changes', 'woocommerce' ); ?></button>
    <input type="hidden" name="action" value="save_account_details" />
  </p>

  <?php do_action( 'woocommerce_edit_account_form_end' ); ?>
</form>




output product
=====================================================================================================================================
 <?php 


 echo woocommerce_output_product_categories(); 


if ( ! function_exists( 'woocommerce_subcategory_thumbnail' ) ) {

    /**
     * Show subcategory thumbnails.
     *
     * @param mixed $category Category.
     */
    function woocommerce_subcategory_thumbnail( $category ) {
        $small_thumbnail_size = apply_filters( 'subcategory_archive_thumbnail_size', 'woocommerce_thumbnail' );
        $dimensions           = wc_get_image_size( $small_thumbnail_size );
        $thumbnail_id         = get_term_meta( $category->term_id, 'thumbnail_id', true );

        if ( $thumbnail_id ) {
            $image        = wp_get_attachment_image_src( $thumbnail_id, $small_thumbnail_size );
            $image        = $image[0];
            $image_srcset = function_exists( 'wp_get_attachment_image_srcset' ) ? wp_get_attachment_image_srcset( $thumbnail_id, $small_thumbnail_size ) : false;
            $image_sizes  = function_exists( 'wp_get_attachment_image_sizes' ) ? wp_get_attachment_image_sizes( $thumbnail_id, $small_thumbnail_size ) : false;
        } else {
            $image        = wc_placeholder_img_src();
            $image_srcset = false;
            $image_sizes  = false;
        }

        if ( $image ) {
            // Prevent esc_url from breaking spaces in urls for image embeds.
            // Ref: https://core.trac.wordpress.org/ticket/23605.
            $image = str_replace( ' ', '%20', $image );

            // Add responsive image markup if available.
            if ( $image_srcset && $image_sizes ) {
                echo '<div class="category-image-wrapp"><img clas="category-image" src="' . esc_url( $image ) . '" alt="' . esc_attr( $category->name ) . '" width="' . esc_attr( $dimensions['width'] ) . '" height="' . esc_attr( $dimensions['height'] ) . '" srcset="' . esc_attr( $image_srcset ) . '" sizes="' . esc_attr( $image_sizes ) . '" /></div>';
            } else {
                echo '<div class="category-image-wrapp"><img  clas="category-image" src="' . esc_url( $image ) . '" alt="' . esc_attr( $category->name ) . '" width="' . esc_attr( $dimensions['width'] ) . '" height="' . esc_attr( $dimensions['height'] ) . '" /></div>';
            }
        }
    }
}



if ( ! function_exists( 'woocommerce_template_loop_category_title' ) ) {

    /**
     * Show the subcategory title in the product loop.
     *
     * @param object $category Category object.
     */
    function woocommerce_template_loop_category_title( $category ) {
        ?>
    <div class="hover-mask">
        <h3 class="category-title">
            <?php
            echo esc_html( $category->name );

            if ( $category->count > 0 ) {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo apply_filters( 'woocommerce_subcategory_count_html', ' <div class="more-products">(' . esc_html( $category->count ) . ')</div>', $category );
            }
            ?>
        </h3>
    </div>
        <?php
    }
}


   Woocommerce Quick view::
  ==============================================================================================================================

  <?php echo do_shortcode('[yith_quick_view]')?>

.INCLUDE/frondent

Button icom:
        $button = '<a href="" class="yith-wcqv-button" data-product_id="' . esc_attr( $product_id ) . '">' . $label . '<i class="las la-random"></i> </a>';







   Woocommerce Wish list view::
  ==============================================================================================================================
  header shortcode:

<a class="mr-3 d-none d-sm-inline" href="<?php echo esc_url( tinv_url_wishlist_default() ); ?>"><i class="lar la-heart"></i></a>

shop page shortcode:

<div class="card-icons__item"> 
      <?php echo do_shortcode("[ti_wishlists_addtowishlist loop=yes]"); ?>

</div>

 Single page shortcode:
  <?php echo do_shortcode('[ti_wishlists_addtowishlist]')?>


  Remove Button:

  <td>
<button type="submit" class="close-link" name="tinvwl-remove"
value="<?php echo esc_attr( $wl_product['ID'] ); ?>"
title="<?php _e( 'Remove', 'ti-woocommerce-wishlist' ) ?>"><i class="las la-times"></i>
  </button>
</td>



  <td class="product-thumbnail">
              <?php
              $thumbnail = apply_filters( 'tinvwl_wishlist_item_thumbnail', $product->get_image(), $wl_product, $product );

              if ( ! $product->is_visible() ) {
                echo $thumbnail; // WPCS: xss ok.
              } else {
                printf( '<a href="%s">%s</a>', esc_url( $product_url ), $thumbnail ); // WPCS: xss ok.
              }
              ?>
            </td>


<td class="product-name">
              <?php
              if ( ! $product->is_visible() ) {
                echo apply_filters( 'tinvwl_wishlist_item_name', is_callable( array(
                        $product,
                        'get_name'
                    ) ) ? $product->get_name() : $product->get_title(), $wl_product, $product ) . '&nbsp;'; // WPCS: xss ok.
              } else {
                echo apply_filters( 'tinvwl_wishlist_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $product_url ), is_callable( array(
                    $product,
                    'get_name'
                ) ) ? $product->get_name() : $product->get_title() ), $wl_product, $product ); // WPCS: xss ok.
              }

              echo apply_filters( 'tinvwl_wishlist_item_meta_data', tinv_wishlist_get_item_data( $product, $wl_product ), $wl_product, $product ); // WPCS: xss ok.
              ?>
            </td>


Price::

  <?php if ( isset( $wishlist_table_row['colm_price'] ) && $wishlist_table_row['colm_price'] ) { ?>
              <td class="product-price">
                <?php
                echo apply_filters( 'tinvwl_wishlist_item_price', $product->get_price_html(), $wl_product, $product ); // WPCS: xss ok.
                ?>
              </td>
            <?php } ?>



Staock:


<?php if ( isset( $wishlist_table_row['colm_stock'] ) && $wishlist_table_row['colm_stock'] ) { ?>
              <td class="product-stock">
                <?php
                $availability = (array) $product->get_availability();
                if ( ! array_key_exists( 'availability', $availability ) ) {
                  $availability['availability'] = '';
                }
                if ( ! array_key_exists( 'class', $availability ) ) {
                  $availability['class'] = '';
                }
                $availability_html = empty( $availability['availability'] ) ? '<p class="stock ' . esc_attr( $availability['class'] ) . '"><span><i class="ftinvwl ftinvwl-check"></i></span><span class="tinvwl-txt">' . esc_html__( 'In stock', 'ti-woocommerce-wishlist' ) . '</span></p>' : '<p class="stock ' . esc_attr( $availability['class'] ) . '"><span><i class="ftinvwl ftinvwl-' . ( ( 'out-of-stock' === esc_attr( $availability['class'] ) ? 'times' : 'check' ) ) . '"></i></span><span>' . wp_kses_post( $availability['availability'] ) . '</span></p>';

                echo apply_filters( 'tinvwl_wishlist_item_status', $availability_html, $availability['availability'], $wl_product, $product ); // WPCS: xss ok.
                ?>
              </td>
            <?php } ?>


Add To Button:::

          
          
            
            <?php if ( isset( $wishlist_table_row['add_to_cart'] ) && $wishlist_table_row['add_to_cart'] ) { ?>
<td>
                <?php
                if ( apply_filters( 'tinvwl_wishlist_item_action_add_to_cart', $wishlist_table_row['add_to_cart'], $wl_product, $product ) ) {
                  ?>
  <button class="btn-cart btn btn-pink mx-3" name="tinvwl-add-to-cart"
  value="<?php echo esc_attr( $wl_product['ID'] ); ?>"
  title="<?php echo esc_html( apply_filters( 'tinvwl_wishlist_item_add_to_cart', $wishlist_table_row['text_add_to_cart'], $wl_product, $product ) ); ?>">
    <i class="las la-shopping-cart mr-1"></i>
  
    <?php echo wp_kses_post( apply_filters( 'tinvwl_wishlist_item_add_to_cart', $wishlist_table_row['text_add_to_cart'], $wl_product, $product ) ); ?>
  </button>

<?php } elseif ( apply_filters( 'tinvwl_wishlist_item_action_default_loop_button', $wishlist_table_row['add_to_cart'], $wl_product, $product ) ) {
                  woocommerce_template_loop_add_to_cart();
                } ?>
              </td>


            <?php } ?>






add_theme_support("title-tag");


//wp_enqueue scripts

function ecmom_scripts(){
	//for syle
	wp_enqueue_style('bootstrap_css',get_theme_file_uri('/assets/css/bootstrap.min.css'),array(),'v3.2.0');
	wp_enqueue_style('main_css',get_theme_file_uri('/assets/css/main.css'),array(),'v3.2.0');
	wp_enqueue_style('blue',get_theme_file_uri('/assets/css/blue.css'),array(),'v3.2.0');
	wp_enqueue_style('owl.carousel',get_theme_file_uri('/assets/css/owl.carousel.css'),array(),'v3.2.0');
	wp_enqueue_style('animate',get_theme_file_uri('/assets/css/animate.min.css'),array(),'v3.2.0');
	wp_enqueue_style('rateit',get_theme_file_uri('/assets/css/rateit.css'),array(),'v3.2.0');
	wp_enqueue_style('bootstrap_select',get_theme_file_uri('/assets/css/bootstrap-select.min.css'),array(),'v3.2.0');
	wp_enqueue_style('font_awesome',get_theme_file_uri('/assets/css/font-awesome.css'),array(),'v3.2.0');
	wp_enqueue_style('font_awesome',get_theme_file_uri('/assets/css/font-awesome.css'),array(),'v3.2.0');
		wp_enqueue_style('woocommece',get_theme_file_uri('/assets/css/woocommece.css'),array(),'v3.2.0');
	wp_enqueue_style('stylesheet',get_stylesheet_uri());


	//for scripts
	//
	wp_enqueue_script('main_js',get_theme_file_uri('/assets/js/jquery-1.11.1.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('bootstrap',get_theme_file_uri('/assets/js/bootstrap.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('dropdown',get_theme_file_uri('/assets/js//bootstrap-hover-dropdown.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('carousel',get_theme_file_uri('/assets/js/owl.carousel.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('echo',get_theme_file_uri('/assets/js/echo.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('easing',get_theme_file_uri('/assets/js/jquery.easing-1.3.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('slider',get_theme_file_uri('/assets/js/bootstrap-slider.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('rateit',get_theme_file_uri('/assets/js/jquery.rateit.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('lightbox',get_theme_file_uri('/assets/js/lightbox.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('select',get_theme_file_uri('/assets/js/bootstrap-select.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('wow',get_theme_file_uri('/assets/js/wow.min.js'),array(),' v1.11.1',true);
	wp_enqueue_script('scripts',get_theme_file_uri('/assets/js/scripts.js'),array(),' v1.11.1',true);

}
add_action('wp_enqueue_scripts','ecmom_scripts');






/////Category   
 function woocommerce_product_category( $args = array() ) {
    $woocommerce_category_id = get_queried_object_id();
  $args = array(
        'parent' => $woocommerce_category_id
  );
  $terms = get_terms( 'product_cat', $args );
  if ( $terms ) {
        echo '<ul class="woocommerce-categories">';
        foreach ( $terms as $term ) {
            echo '<li class="woocommerce-product-category-page">';
            woocommerce_subcategory_thumbnail( $term );
            echo '<h2>';
            echo '<a href="' .  esc_url( get_term_link( $term ) ) . '" class="' . $term->slug . '">';
            echo $term->name;
            echo '</a>';
            echo '</h2>';
            echo '</li>';
        }
        echo '</ul>';
  }
}
add_action( 'woocommerce_before_shop_loop', 'woocommerce_product_category', 100 );





